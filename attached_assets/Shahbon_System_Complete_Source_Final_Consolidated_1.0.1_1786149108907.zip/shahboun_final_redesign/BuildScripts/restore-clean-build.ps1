$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot
Set-Location $root

dotnet --info
dotnet workload list
dotnet restore .\ShahbounAndroid.sln
dotnet clean .\ShahbounAndroid.sln -c Debug
dotnet build .\ShahbounAndroid.sln -c Debug --no-restore
Write-Host "Debug build completed." -ForegroundColor Green
