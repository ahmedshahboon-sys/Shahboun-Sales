$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot
$out = Join-Path $root 'Artifacts\Debug'
New-Item -ItemType Directory -Force -Path $out | Out-Null
Set-Location $root

dotnet publish .\ShahbounAndroid\ShahbounAndroid.csproj -f net10.0-android -c Debug -p:AndroidPackageFormat=apk -o (Join-Path $out 'Sales')
dotnet publish .\ShahbounLicensing\ShahbounLicensing.csproj -f net10.0-android -c Debug -p:AndroidPackageFormat=apk -o (Join-Path $out 'Licensing')
Write-Host "APK outputs: $out" -ForegroundColor Green
