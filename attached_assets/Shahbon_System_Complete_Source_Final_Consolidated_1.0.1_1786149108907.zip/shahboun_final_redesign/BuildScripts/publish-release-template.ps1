param(
  [Parameter(Mandatory=$true)][string]$SalesKeyStore,
  [Parameter(Mandatory=$true)][string]$SalesAlias,
  [Parameter(Mandatory=$true)][string]$LicensingKeyStore,
  [Parameter(Mandatory=$true)][string]$LicensingAlias
)
$ErrorActionPreference = 'Stop'
if (-not $env:SHAHBOUN_SALES_STORE_PASS -or -not $env:SHAHBOUN_SALES_KEY_PASS -or -not $env:SHAHBOUN_LIC_STORE_PASS -or -not $env:SHAHBOUN_LIC_KEY_PASS) {
  throw 'Set signing passwords in environment variables before running.'
}
$root = Split-Path -Parent $PSScriptRoot
$out = Join-Path $root 'Artifacts\Release'
New-Item -ItemType Directory -Force -Path $out | Out-Null
Set-Location $root

dotnet publish .\ShahbounAndroid\ShahbounAndroid.csproj -f net10.0-android -c Release -p:AndroidPackageFormat=apk -p:AndroidKeyStore=true -p:AndroidSigningKeyStore="$SalesKeyStore" -p:AndroidSigningKeyAlias="$SalesAlias" -p:AndroidSigningStorePass="env:SHAHBOUN_SALES_STORE_PASS" -p:AndroidSigningKeyPass="env:SHAHBOUN_SALES_KEY_PASS" -o (Join-Path $out 'Sales')

dotnet publish .\ShahbounLicensing\ShahbounLicensing.csproj -f net10.0-android -c Release -p:AndroidPackageFormat=apk -p:AndroidKeyStore=true -p:AndroidSigningKeyStore="$LicensingKeyStore" -p:AndroidSigningKeyAlias="$LicensingAlias" -p:AndroidSigningStorePass="env:SHAHBOUN_LIC_STORE_PASS" -p:AndroidSigningKeyPass="env:SHAHBOUN_LIC_KEY_PASS" -o (Join-Path $out 'Licensing')
Write-Host "Signed APK outputs: $out" -ForegroundColor Green
