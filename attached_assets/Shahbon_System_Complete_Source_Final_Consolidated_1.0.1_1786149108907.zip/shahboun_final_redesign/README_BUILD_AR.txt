منظومة شهبون - حل يحتوي مشروعين Android

1) ShahbounAndroid: منظومة المبيعات
2) ShahbounLicensing: تطبيق إدارة التراخيص

أوامر البناء:
dotnet restore
dotnet build ShahbounAndroid.sln -c Release
dotnet publish .\ShahbounAndroid\ShahbounAndroid.csproj -f net10.0-android -c Release -p:AndroidPackageFormat=apk
dotnet publish .\ShahbounLicensing\ShahbounLicensing.csproj -f net10.0-android -c Release -p:AndroidPackageFormat=apk

ملاحظة: هذه الحزمة لم يتم تجميعها داخل بيئة ChatGPT لعدم توفر .NET Android SDK هنا. يلزم فتحها في Visual Studio وتجربة البناء، ثم إرسال أي خطأ كما هو لتصحيحه.
