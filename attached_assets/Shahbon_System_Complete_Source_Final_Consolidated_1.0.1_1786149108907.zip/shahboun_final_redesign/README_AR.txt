منظومة شهبون — الحزمة الموحّدة النهائية للمراجعة والبناء 1.0.1

تحتوي الحزمة على التطبيقين كاملين داخل حل واحد:
1) ShahbounAndroid — منظومة المبيعات.
2) ShahbounLicensing — تطبيق التراخيص.

الإضافات في هذه الدفعة:
- قارئ باركود بالكاميرا داخل المنتجات ونقطة البيع.
- فواتير كاملة مع شعار المتجر وفتح مباشر ومشاركة وطباعة/حفظ PDF عبر نظام أندرويد.
- حسابات مصرفية وQR دفع ومشاركة QR.
- تسجيل الحوالات كـ«قيد المراجعة» وعدم اعتمادها تلقائيًا.
- نسخ احتياطي ZIP واستعادة مع نسخة أمان تلقائية.
- التحقق من تحديثات Google Drive عبر ملف JSON ثابت.
- رفع إصدار منظومة المبيعات إلى 0.8.0.

البناء:
dotnet restore ShahbounAndroid.sln
dotnet build ShahbounAndroid.sln -c Release

dotnet publish .\ShahbounAndroid\ShahbounAndroid.csproj -f net10.0-android -c Release -p:AndroidPackageFormat=apk
dotnet publish .\ShahbounLicensing\ShahbounLicensing.csproj -f net10.0-android -c Release -p:AndroidPackageFormat=apk

مهم: أول بناء يحتاج إنترنت لتنزيل حزم NuGet. اختبر الكاميرا والطابعة على هاتف أندرويد حقيقي.


إضافات الحزمة 1.0.1:
- تضمين صور التصميم المرجعية ونظام تصميم مكتوب.
- تضمين سكربتات Restore/Clean/Build ونشر Debug وRelease.
- تثبيت جميع متطلبات المشروع في ملفات التوثيق.
- إضافة إفادة المستخدم بأن المراحل السابقة جُرّبت على هاتف حقيقي.
- لا تحتوي الحزمة على مفاتيح توقيع أو أسرار إنتاج.
