namespace ShahbounLicensing;
public static class LUi
{
    public static Color Primary => (Color)Application.Current!.Resources["Primary"];
    public static Color Accent => (Color)Application.Current!.Resources["Accent"];
    public static Color Red => (Color)Application.Current!.Resources["Danger"];
    public static Color Border => (Color)Application.Current!.Resources["LineColor"];
    public static Color Muted => (Color)Application.Current!.Resources["MutedText"];
    public static Entry E(string p,bool pw=false)=>new(){Placeholder=p,IsPassword=pw,FlowDirection=FlowDirection.RightToLeft,ClearButtonVisibility=ClearButtonVisibility.WhileEditing};
    public static Button B(string t,Color? c=null)=>new(){Text=t,BackgroundColor=c??Primary,TextColor=Colors.White};
    public static Border Card(View v)=>new(){BackgroundColor=(Color)Application.Current!.Resources["CardSurface"],Stroke=Border,StrokeThickness=1,Padding=16,StrokeShape=new Microsoft.Maui.Controls.Shapes.RoundRectangle{CornerRadius=18},Shadow=new Shadow{Brush=Brush.Black,Opacity=.08f,Radius=10,Offset=new Point(0,3)},Content=v};
}
