using ShahbounLicensing.Pages;
using ShahbounLicensing.Services;
namespace ShahbounLicensing;
public partial class App:Application
{
    public App(){InitializeComponent();LicensingServices.Theme.Apply();}
    protected override Window CreateWindow(IActivationState? s)=>new(new NavigationPage(LicensingServices.Auth.IsConfigured?new LoginPage():new SetupPage()));
}
