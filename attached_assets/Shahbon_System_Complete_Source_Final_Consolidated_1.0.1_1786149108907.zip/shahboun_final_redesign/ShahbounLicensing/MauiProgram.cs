namespace ShahbounLicensing; public static class MauiProgram{public static MauiApp CreateMauiApp(){var b=MauiApp.CreateBuilder();b.UseMauiApp<App>();return b.Build();}}
