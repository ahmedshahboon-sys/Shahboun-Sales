namespace ShahbounLicensing.Services;
public static class LicensingServices
{
    public static AuthService Auth { get; } = new();
    public static SigningKeyVault KeyVault { get; } = new();
    public static LicenseCrypto Crypto { get; } = new(KeyVault);
    public static ThemeService Theme { get; } = new();
    public static LicenseDatabase Database { get; } = new();
    public static string? SessionPassword { get; set; }
}
