using System.Security.Cryptography;
using System.Text.Json;

namespace ShahbounLicensing.Services;

public sealed class LicenseCrypto
{
    readonly SigningKeyVault vault;
    public LicenseCrypto(SigningKeyVault vault) => this.vault = vault;

    public string Create(string deviceCode, string customerName, string password)
    {
        var payload = new LicensePayload
        {
            Product = "SHAHBOUN-ANDROID",
            DeviceCode = deviceCode.Trim().ToUpperInvariant(),
            Lifetime = true,
            IssuedAtUtc = DateTime.UtcNow,
            CustomerName = customerName.Trim(),
            LicenseId = Guid.NewGuid().ToString("N")
        };
        var data = JsonSerializer.SerializeToUtf8Bytes(payload);
        using var rsa = vault.Open(password);
        var signature = rsa.SignData(data, HashAlgorithmName.SHA256, RSASignaturePadding.Pkcs1);
        return $"{Base64Url(data)}.{Base64Url(signature)}";
    }

    public string CreateReset(string deviceCode, string password)
    {
        var payload = new ResetPayload
        {
            Product = "SHAHBOUN-RESET",
            DeviceCode = deviceCode.Trim().ToUpperInvariant(),
            IssuedAtUtc = DateTime.UtcNow,
            ExpiresAtUtc = DateTime.UtcNow.AddHours(2),
            Nonce = Guid.NewGuid().ToString("N")
        };
        var data = JsonSerializer.SerializeToUtf8Bytes(payload);
        using var rsa = vault.Open(password);
        var signature = rsa.SignData(data, HashAlgorithmName.SHA256, RSASignaturePadding.Pkcs1);
        return $"{Base64Url(data)}.{Base64Url(signature)}";
    }

    static string Base64Url(byte[] data) => Convert.ToBase64String(data).TrimEnd('=').Replace('+','-').Replace('/','_');

    sealed class LicensePayload
    {
        public string Product { get; set; } = "";
        public string DeviceCode { get; set; } = "";
        public bool Lifetime { get; set; }
        public DateTime IssuedAtUtc { get; set; }
        public string CustomerName { get; set; } = "";
        public string LicenseId { get; set; } = "";
    }
    sealed class ResetPayload
    {
        public string Product { get; set; } = "";
        public string DeviceCode { get; set; } = "";
        public DateTime IssuedAtUtc { get; set; }
        public DateTime ExpiresAtUtc { get; set; }
        public string Nonce { get; set; } = "";
    }
}
