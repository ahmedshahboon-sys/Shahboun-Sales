using System.Security.Cryptography;
using System.Text;

namespace ShahbounLicensing.Services;

public sealed class SigningKeyVault
{
    const string CipherKey = "signing_cipher";
    const string SaltKey = "signing_salt";
    const string NonceKey = "signing_nonce";
    const string TagKey = "signing_tag";

    // مفتاح تطوير مطابق للمفتاح العام داخل منظومة المبيعات.
    // عند اعتماد النسخة للبيع يجب تدويره مرة واحدة من شاشة الأمان ثم إعادة بناء التطبيقين.
    const string DevelopmentPrivateKeyPem = """
-----BEGIN PRIVATE KEY-----
MIIEvAIBADANBgkqhkiG9w0BAQEFAASCBKYwggSiAgEAAoIBAQDGpOhli9JUfuux
e9UMn6e/IKbvHkpF+t3WPgAeL31Lx611ncwIAha5xoNFgmnFYX7JRTzOKVfiKJ8V
vgf5T+tXBsoM68TGia99xpSd6VH+43YAxAykcazy+wZNX7EdrBdYrEw/0d1/71Bi
Mg4uEn1197//gSsvudaQdvpwH78VpLU6xcYmWQPDbHcdxtulJP0WyuHpBTD/hJVd
tk4PeiXilUK6dzGN1cQWmAYDE1B1YKR8vzLxastkIpNCBpIpm8j5Wap2Tfo+afY5
mNx7UfmDhV85L8V+HsRn8pzFXO42rh6X9XsSs/+r3LKgHrk30CC0aTxEFM6B50sB
uaWFHB8HAgMBAAECggEAC4cJXM84OvgMlHBOZPJPk+tV/1K01l/LB4JHPnkyCQzt
jNbwlAG5sOPgvU679ZzanzJ551rbLerT5I6dEYOTnClu3etsBWYlvXj3Ked0Kdmo
Vj4KSnFgVc9pxmFdurjrDUBzwlEFohrQrDTMbDGy1H7hRkyy0A0K8wznK/eOVA1F
yaSY1H9XE/pGUG8RC9Ou9MnG4iaD81h6XaO0EbS6VwkdwHckq9ejrqEFkoz5PuRP
ocIH7Znglcq5SkCaHxPNm/B2ZBdA8EsqXb/X8m2Vqm/JrfuezojP36xGW/pyfnkr
7/2vk2g1yiUaOw53U2vJx6CaUuwC10ugzsji4FduPQKBgQDzOHQZafTMfFY4iNCW
IbU3EMzcdxX9nxxuUSKA5pxQ1hhFyi9wMtIA2MLuUWnULgnjUBEYORsWhCmsxSIy
Rl/BqkoAOSIld1ftNmCE6phqqtJytHMQemSRhHQ87m7gs9etokbCszbiKTpOMCPb
P/DMieEfwGtmfIIUeg0dCJ8A8wKBgQDRFNwxsZ8KtO2XMhxTp/ukBXjD1ObKg2oA
KDoSPUl75fdR7/ZGlwwvr6HxrhpFDtZsCs+f5lUZ93Rm18Vf4CSom0Pgi5Gx9nZo
2T95pAe2ZvpVnqS2kyO0sLUs99Myb+8mn+30pRqlg21KkUwqdDDJHaNXrh/emtHQ
g0Y9wRfOnQKBgAk/kEqXGNPdtnmX2jabOYTKgr+vV4q5Th9zvlggbLk2Kt4cfglK
JWoa0+6z8c47oeye0seVBE6q39rN9CrtOh7nFsFDauT50MIYWzsyoHEN5cquyeFK
hiByZOkcN+Mbc4wKq54jqmaXIrxuYC6qE8HzTDgk3PCcs2WL7ou4FDO5AoGAN4YO
o7PDxJgfsFNCaoTlsr0xQPA9CfK0J66HHWjhJuH/N+c9w6lBNzixDPlrSIOUNcT5
NkF4wBiS9OzAIaHomk4BTJRD8Lq+30EyNh91XN8kA7DJlSKmDMoQkwyNLYvEOsGl
854U4XdxgqfrTirk+cPBKPu4wujiZzk1YhjxNZECgYBc2oyy7RpyxrLS/iRrEHy4
OL3vHYxGeFpVXViURA3b1ztBzWE39hYBqAHZJZKe5coF/yzIKncN5E1wEeZWmYhZ
8wE0iz7aLT+R+OPCBStJYv27Oxx0DkZ8fLNjrj5EG86fN05uVZ3Uc5XvJcpmVG/X
V+3QOOJTFuP66ky61Kxzkg==
-----END PRIVATE KEY-----
""";

    public bool IsProvisioned => Preferences.ContainsKey(CipherKey);

    public void ProvisionDevelopmentKey(string password)
    {
        if (password.Length < 6) throw new ArgumentException("كلمة المرور قصيرة.");
        Protect(DevelopmentPrivateKeyPem, password);
    }

    public void ImportPrivateKey(string pem, string password)
    {
        using var rsa = RSA.Create();
        rsa.ImportFromPem(pem);
        Protect(pem, password);
    }

    public RSA Open(string password)
    {
        if (!IsProvisioned) throw new InvalidOperationException("مفتاح التوقيع غير مهيأ.");
        var salt = Convert.FromBase64String(Preferences.Get(SaltKey, ""));
        var nonce = Convert.FromBase64String(Preferences.Get(NonceKey, ""));
        var tag = Convert.FromBase64String(Preferences.Get(TagKey, ""));
        var cipher = Convert.FromBase64String(Preferences.Get(CipherKey, ""));
        var key = Rfc2898DeriveBytes.Pbkdf2(password, salt, 250_000, HashAlgorithmName.SHA256, 32);
        var plain = new byte[cipher.Length];
        using var aes = new AesGcm(key, 16);
        aes.Decrypt(nonce, cipher, tag, plain, Encoding.UTF8.GetBytes("SHAHBOUN-LICENSE-KEY"));
        var rsa = RSA.Create();
        rsa.ImportFromPem(Encoding.UTF8.GetString(plain));
        CryptographicOperations.ZeroMemory(plain);
        CryptographicOperations.ZeroMemory(key);
        return rsa;
    }

    void Protect(string pem, string password)
    {
        var salt = RandomNumberGenerator.GetBytes(32);
        var nonce = RandomNumberGenerator.GetBytes(12);
        var key = Rfc2898DeriveBytes.Pbkdf2(password, salt, 250_000, HashAlgorithmName.SHA256, 32);
        var plain = Encoding.UTF8.GetBytes(pem);
        var cipher = new byte[plain.Length];
        var tag = new byte[16];
        using var aes = new AesGcm(key, 16);
        aes.Encrypt(nonce, plain, cipher, tag, Encoding.UTF8.GetBytes("SHAHBOUN-LICENSE-KEY"));
        Preferences.Set(SaltKey, Convert.ToBase64String(salt));
        Preferences.Set(NonceKey, Convert.ToBase64String(nonce));
        Preferences.Set(TagKey, Convert.ToBase64String(tag));
        Preferences.Set(CipherKey, Convert.ToBase64String(cipher));
        CryptographicOperations.ZeroMemory(plain);
        CryptographicOperations.ZeroMemory(key);
    }
}
