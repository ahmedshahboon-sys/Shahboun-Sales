using System.Security.Cryptography;
using System.Text;

namespace ShahbounLicensing.Services;

public sealed class AuthService
{
    const string UserKey = "lic_user";
    const string HashKey = "lic_hash";
    const string SaltKey = "lic_salt";
    const string AttemptsKey = "lic_attempts";
    const string LockKey = "lic_lock_until";

    public bool IsConfigured => Preferences.ContainsKey(UserKey) && Preferences.ContainsKey(HashKey);

    public void Configure(string username, string password)
    {
        if (string.IsNullOrWhiteSpace(username)) throw new ArgumentException("اسم المستخدم مطلوب.");
        if (password.Length < 6) throw new ArgumentException("كلمة المرور يجب ألا تقل عن 6 أحرف.");
        var salt = RandomNumberGenerator.GetBytes(32);
        Preferences.Set(UserKey, username.Trim());
        Preferences.Set(SaltKey, Convert.ToBase64String(salt));
        Preferences.Set(HashKey, Hash(password, salt));
        Preferences.Set(AttemptsKey, 0);
        Preferences.Remove(LockKey);
    }

    public bool Validate(string username, string password, out string message)
    {
        var lockUntilRaw = Preferences.Get(LockKey, "");
        if (DateTimeOffset.TryParse(lockUntilRaw, out var lockUntil) && lockUntil > DateTimeOffset.UtcNow)
        {
            message = $"تم قفل الدخول مؤقتًا. حاول بعد {Math.Ceiling((lockUntil-DateTimeOffset.UtcNow).TotalMinutes)} دقيقة.";
            return false;
        }

        var user = Preferences.Get(UserKey, "");
        var saltRaw = Preferences.Get(SaltKey, "");
        var expected = Preferences.Get(HashKey, "");
        if (string.IsNullOrWhiteSpace(user) || string.IsNullOrWhiteSpace(saltRaw) || string.IsNullOrWhiteSpace(expected))
        {
            message = "لم تتم تهيئة حساب المالك بعد.";
            return false;
        }

        var actual = Hash(password, Convert.FromBase64String(saltRaw));
        var ok = string.Equals(user, username.Trim(), StringComparison.Ordinal) &&
                 CryptographicOperations.FixedTimeEquals(Convert.FromHexString(expected), Convert.FromHexString(actual));
        if (ok)
        {
            Preferences.Set(AttemptsKey, 0);
            Preferences.Remove(LockKey);
            message = "تم تسجيل الدخول.";
            return true;
        }

        var attempts = Preferences.Get(AttemptsKey, 0) + 1;
        Preferences.Set(AttemptsKey, attempts);
        if (attempts >= 5)
        {
            Preferences.Set(AttemptsKey, 0);
            Preferences.Set(LockKey, DateTimeOffset.UtcNow.AddMinutes(5).ToString("O"));
            message = "محاولات كثيرة. تم قفل الدخول لمدة 5 دقائق.";
        }
        else message = $"بيانات الدخول غير صحيحة. متبقي {5-attempts} محاولات.";
        return false;
    }

    public void ChangeCredentials(string currentPassword, string newUsername, string newPassword)
    {
        var currentUser = Preferences.Get(UserKey, "");
        if (!Validate(currentUser, currentPassword, out _)) throw new InvalidOperationException("كلمة المرور الحالية غير صحيحة.");
        Configure(newUsername, newPassword);
    }

    static string Hash(string password, byte[] salt)
    {
        var bytes = Rfc2898DeriveBytes.Pbkdf2(Encoding.UTF8.GetBytes(password), salt, 210_000, HashAlgorithmName.SHA256, 32);
        return Convert.ToHexString(bytes);
    }
}
