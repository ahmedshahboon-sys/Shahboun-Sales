using ShahbounLicensing.Services;
namespace ShahbounLicensing.Pages;
public sealed class ResetCodePage:ContentPage
{
    readonly Entry device=LUi.E("كود جهاز الزبون");
    readonly Label result=new(){FontSize=14,FontAttributes=FontAttributes.Bold,TextColor=LUi.Accent,HorizontalTextAlignment=TextAlignment.Center,LineBreakMode=LineBreakMode.CharacterWrap};
    public ResetCodePage()
    {
        Title="رمز استعادة المدير";
        var b=LUi.B("توليد رمز استعادة صالح لساعتين",LUi.Accent);
        b.Clicked+=async(_,_)=>
        {
            if(string.IsNullOrWhiteSpace(device.Text)||string.IsNullOrWhiteSpace(LicensingServices.SessionPassword)){await DisplayAlertAsync("تنبيه","أدخل كود الجهاز وتأكد من تسجيل الدخول.","حسناً");return;}
            try{result.Text=LicensingServices.Crypto.CreateReset(device.Text,LicensingServices.SessionPassword);}
            catch(Exception ex){await DisplayAlertAsync("تعذر التوقيع",ex.Message,"حسناً");}
        };
        var copy=LUi.B("نسخ الرمز");copy.Clicked+=async(_,_)=>{if(!string.IsNullOrWhiteSpace(result.Text))await Clipboard.SetTextAsync(result.Text);};
        Content=new VerticalStackLayout{Padding=20,Spacing=14,Children={device,b,LUi.Card(new VerticalStackLayout{Spacing=10,Children={result,copy}})}};
    }
}
