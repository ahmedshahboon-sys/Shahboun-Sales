using ShahbounLicensing.Services;
namespace ShahbounLicensing.Pages;

public sealed class SettingsPage : ContentPage
{
    readonly Picker theme = new() { Title = "ألوان التطبيق", ItemsSource = new[] { "شهبون الكلاسيكي", "الأزرق الاحترافي", "الرمادي الفاخر" } };
    readonly Picker mode = new() { Title = "وضع العرض", ItemsSource = new[] { "تلقائي حسب الهاتف", "فاتح", "مظلم" } };

    public SettingsPage()
    {
        Title = "الإعدادات والأمان";
        var apply = LUi.B("تطبيق الثيم", LUi.Accent);
        apply.Clicked += (_, _) =>
        {
            var t = theme.SelectedIndex switch { 1 => "blue", 2 => "luxury", _ => "classic" };
            var m = mode.SelectedIndex switch { 1 => "light", 2 => "dark", _ => "system" };
            LicensingServices.Theme.Apply(t, m);
            Application.Current!.Windows[0].Page = new NavigationPage(new DashboardPage());
        };

        var change = LUi.B("تغيير اسم المستخدم وكلمة المرور");
        change.Clicked += async (_, _) =>
        {
            var current = await DisplayPromptAsync("التحقق", "أدخل كلمة المرور الحالية:", "متابعة", "إلغاء", keyboard: Keyboard.Text);
            if (string.IsNullOrWhiteSpace(current)) return;
            var u = await DisplayPromptAsync("اسم المستخدم", "أدخل اسم المستخدم الجديد:", "متابعة", "إلغاء");
            if (string.IsNullOrWhiteSpace(u)) return;
            var p = await DisplayPromptAsync("كلمة المرور", "أدخل كلمة مرور جديدة لا تقل عن 6 أحرف:", "حفظ", "إلغاء");
            if (string.IsNullOrWhiteSpace(p)) return;
            try
            {
                LicensingServices.Auth.ChangeCredentials(current, u, p);
                await DisplayAlertAsync("تم", "تم تغيير بيانات الدخول. أعد تسجيل الدخول.", "حسناً");
                LicensingServices.SessionPassword = null;
                Application.Current!.Windows[0].Page = new NavigationPage(new LoginPage());
            }
            catch (Exception ex) { await DisplayAlertAsync("تعذر التغيير", ex.Message, "حسناً"); }
        };

        var lockNow = LUi.B("قفل التطبيق الآن", LUi.Red);
        lockNow.Clicked += (_, _) => { LicensingServices.SessionPassword = null; Application.Current!.Windows[0].Page = new NavigationPage(new LoginPage()); };

        var appearance = new VerticalStackLayout { Spacing = 10 };
        appearance.Children.Add(new Label { Text = "المظهر", FontSize = 20, FontAttributes = FontAttributes.Bold });
        appearance.Children.Add(theme); appearance.Children.Add(mode); appearance.Children.Add(apply);

        var security = new VerticalStackLayout { Spacing = 10 };
        security.Children.Add(new Label { Text = "الحماية", FontSize = 20, FontAttributes = FontAttributes.Bold });
        security.Children.Add(new Label { Text = "كلمة المرور تُخزن كتجزئة قوية، ومفتاح التوقيع مشفر داخل الجهاز.", TextColor = LUi.Muted });
        security.Children.Add(change); security.Children.Add(lockNow);

        var keyInfo = new VerticalStackLayout { Spacing = 10 };
        keyInfo.Children.Add(new Label { Text = "مفتاح التوقيع", FontSize = 20, FontAttributes = FontAttributes.Bold });
        keyInfo.Children.Add(new Label { Text = LicensingServices.KeyVault.IsProvisioned ? "مفتاح التوقيع مهيأ ومشفر." : "مفتاح التوقيع غير مهيأ.", TextColor = LUi.Muted });
        keyInfo.Children.Add(new Label { Text = "قبل البيع النهائي يجب إنشاء نسخة احتياطية مشفرة للمفتاح وحفظها خارج الهاتف.", FontSize = 12, TextColor = LUi.Muted });

        var body = new VerticalStackLayout { Padding = 18, Spacing = 12, MaximumWidthRequest = 760, HorizontalOptions = LayoutOptions.Center };
        body.Children.Add(LUi.Card(appearance)); body.Children.Add(LUi.Card(security)); body.Children.Add(LUi.Card(keyInfo));
        Content = new ScrollView { Content = body };
    }

    protected override void OnAppearing()
    {
        base.OnAppearing();
        theme.SelectedIndex = LicensingServices.Theme.ThemeName switch { "blue" => 1, "luxury" => 2, _ => 0 };
        mode.SelectedIndex = LicensingServices.Theme.Mode switch { "light" => 1, "dark" => 2, _ => 0 };
    }
}
