using ShahbounLicensing.Services;
namespace ShahbounLicensing.Pages;

public sealed class SetupPage : ContentPage
{
    readonly Entry user = LUi.E("اسم المستخدم الخاص بك");
    readonly Entry pass = LUi.E("كلمة مرور قوية", true);
    readonly Entry confirm = LUi.E("تأكيد كلمة المرور", true);

    public SetupPage()
    {
        Title = "تهيئة المالك";
        var create = LUi.B("إنشاء الحساب وتهيئة التوقيع", LUi.Accent);
        create.Clicked += async (_, _) =>
        {
            try
            {
                if (pass.Text != confirm.Text)
                {
                    await DisplayAlertAsync("تنبيه", "كلمتا المرور غير متطابقتين.", "حسناً");
                    return;
                }
                LicensingServices.Auth.Configure(user.Text ?? "", pass.Text ?? "");
                LicensingServices.KeyVault.ProvisionDevelopmentKey(pass.Text ?? "");
                LicensingServices.SessionPassword = pass.Text;
                Application.Current!.Windows[0].Page = new NavigationPage(new DashboardPage());
            }
            catch (Exception ex) { await DisplayAlertAsync("تعذر الإعداد", ex.Message, "حسناً"); }
        };

        var form = new VerticalStackLayout { Spacing = 12 };
        form.Children.Add(user); form.Children.Add(pass); form.Children.Add(confirm); form.Children.Add(create);
        form.Children.Add(new Label { Text = "سيتم تشفير مفتاح التوقيع بكلمة المرور التي تختارها.", FontSize = 12, TextColor = LUi.Muted, HorizontalTextAlignment = TextAlignment.Center });
        var body = new VerticalStackLayout { Padding = 24, Spacing = 16, VerticalOptions = LayoutOptions.Center };
        body.Children.Add(new Label { Text = "شهبون لإدارة التراخيص", FontSize = 29, FontAttributes = FontAttributes.Bold, HorizontalTextAlignment = TextAlignment.Center });
        body.Children.Add(new Label { Text = "تهيئة آمنة لأول تشغيل", TextColor = LUi.Muted, HorizontalTextAlignment = TextAlignment.Center });
        body.Children.Add(LUi.Card(form));
        Content = new ScrollView { Content = body };
    }
}
