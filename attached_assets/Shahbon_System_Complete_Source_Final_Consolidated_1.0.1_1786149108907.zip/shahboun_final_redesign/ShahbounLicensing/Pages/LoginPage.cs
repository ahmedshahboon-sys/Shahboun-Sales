using ShahbounLicensing.Services;
namespace ShahbounLicensing.Pages;

public sealed class LoginPage : ContentPage
{
    readonly Entry user = LUi.E("اسم المستخدم");
    readonly Entry pass = LUi.E("كلمة المرور", true);

    public LoginPage()
    {
        Title = "تسجيل الدخول";
        var login = LUi.B("دخول إلى تطبيق التراخيص", LUi.Accent);
        login.Clicked += async (_, _) =>
        {
            if (LicensingServices.Auth.Validate(user.Text ?? "", pass.Text ?? "", out var message))
            {
                try
                {
                    using var rsa = LicensingServices.KeyVault.Open(pass.Text ?? "");
                    LicensingServices.SessionPassword = pass.Text;
                    Application.Current!.Windows[0].Page = new NavigationPage(new DashboardPage());
                }
                catch
                {
                    await DisplayAlertAsync("خطأ أمان", "تعذر فتح مفتاح التوقيع بهذه الكلمة.", "حسناً");
                }
            }
            else await DisplayAlertAsync("تعذر الدخول", message, "حسناً");
        };

        var form = new VerticalStackLayout { Spacing = 12 };
        form.Children.Add(user);
        form.Children.Add(pass);
        form.Children.Add(login);
        form.Children.Add(new Label { Text = "بعد 5 محاولات خاطئة يُقفل الدخول مؤقتًا.", FontSize = 12, TextColor = LUi.Muted, HorizontalTextAlignment = TextAlignment.Center });

        var body = new VerticalStackLayout { VerticalOptions = LayoutOptions.Center, Spacing = 16 };
        body.Children.Add(new Label { Text = "شهبون لإدارة التراخيص", FontSize = 29, FontAttributes = FontAttributes.Bold, HorizontalTextAlignment = TextAlignment.Center });
        body.Children.Add(new Label { Text = "تفعيل الزبائن وإدارة السجلات بأمان", TextColor = LUi.Muted, HorizontalTextAlignment = TextAlignment.Center });
        body.Children.Add(LUi.Card(form));
        Content = new Grid { Padding = 24, Children = { body } };
    }
}
