using ShahbounLicensing.Models;using ShahbounLicensing.Services;
namespace ShahbounLicensing.Pages;
public sealed class GenerateLicensePage:ContentPage
{
    readonly LicenseDatabase db=LicensingServices.Database;
    readonly Entry store=LUi.E("اسم المتجر"),owner=LUi.E("اسم صاحب النشاط"),phone=LUi.E("رقم الهاتف"),device=LUi.E("كود الجهاز");
    readonly Editor notes=new(){Placeholder="ملاحظات",HeightRequest=90};
    readonly Label result=new(){FontSize=15,FontAttributes=FontAttributes.Bold,TextColor=LUi.Accent,HorizontalTextAlignment=TextAlignment.Center,LineBreakMode=LineBreakMode.CharacterWrap};
    public GenerateLicensePage()
    {
        Title="توليد كود تفعيل";
        var gen=LUi.B("توليد وحفظ كود التفعيل",LUi.Accent);
        gen.Clicked+=async(_,_)=>
        {
            if(new[]{store.Text,owner.Text,phone.Text,device.Text}.Any(string.IsNullOrWhiteSpace)){await DisplayAlertAsync("نقص بيانات","أكمل كل البيانات المطلوبة.","حسناً");return;}
            if(string.IsNullOrWhiteSpace(LicensingServices.SessionPassword)){await DisplayAlertAsync("انتهت الجلسة","أعد تسجيل الدخول.","حسناً");return;}
            try
            {
                var code=LicensingServices.Crypto.Create(device.Text!,owner.Text!,LicensingServices.SessionPassword);
                await db.Save(new CustomerRecord{StoreName=store.Text!,OwnerName=owner.Text!,Phone=phone.Text!,DeviceCode=device.Text!.Trim().ToUpperInvariant(),LicenseCode=code,Notes=notes.Text??""});
                result.Text=code;
            }
            catch(Exception ex){await DisplayAlertAsync("تعذر التوقيع",ex.Message,"حسناً");}
        };
        var copy=LUi.B("نسخ الكود");copy.Clicked+=async(_,_)=>{if(!string.IsNullOrWhiteSpace(result.Text))await Clipboard.SetTextAsync(result.Text);};
        var share=LUi.B("مشاركة الكود");share.Clicked+=async(_,_)=>{if(!string.IsNullOrWhiteSpace(result.Text))await Share.Default.RequestAsync(new ShareTextRequest{Title="كود تفعيل منظومة شهبون",Text=$"اسم المتجر: {store.Text}\nاسم الزبون: {owner.Text}\nكود التفعيل:\n{result.Text}"});};
        Content=new ScrollView{Content=new VerticalStackLayout{Padding=18,Spacing=12,MaximumWidthRequest=760,HorizontalOptions=LayoutOptions.Center,Children={store,owner,phone,device,notes,gen,LUi.Card(new VerticalStackLayout{Spacing=10,Children={new Label{Text="كود التفعيل الموقّع",TextColor=LUi.Muted,HorizontalTextAlignment=TextAlignment.Center},result,copy,share}})}}};
    }
}
