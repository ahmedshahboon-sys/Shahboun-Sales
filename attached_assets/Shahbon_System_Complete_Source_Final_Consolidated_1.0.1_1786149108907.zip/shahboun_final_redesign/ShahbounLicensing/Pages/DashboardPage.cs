using ShahbounLicensing.Services;
namespace ShahbounLicensing.Pages;
public sealed class DashboardPage:ContentPage
{
    readonly Label clock=new(){FontSize=16,FontAttributes=FontAttributes.Bold,HorizontalTextAlignment=TextAlignment.End};
    IDispatcherTimer? timer;
    public DashboardPage()
    {
        Title="لوحة التراخيص";
        var grid=new Grid{ColumnSpacing=12,RowSpacing=12,ColumnDefinitions={new ColumnDefinition(GridLength.Star),new ColumnDefinition(GridLength.Star)}};
        var items=new(string,string,Func<Page>)[]{("🔑","توليد تفعيل",()=>new GenerateLicensePage()),("👥","سجل الزبائن",()=>new CustomersPage()),("♻️","رمز استعادة",()=>new ResetCodePage()),("⚙️","الإعدادات والأمان",()=>new SettingsPage())};
        for(int i=0;i<items.Length;i++){var x=items[i];var b=new Button{Text=$"{x.Item1}\n{x.Item2}",HeightRequest=124,BackgroundColor=(Color)Application.Current!.Resources["CardSurface"],TextColor=(Color)Application.Current.Resources["MainText"],BorderColor=(Color)Application.Current.Resources["LineColor"],BorderWidth=1,CornerRadius=18,FontSize=16};b.Clicked+=async(_,_)=>await Navigation.PushAsync(x.Item3());grid.Add(b,i%2,i/2);}
        var header=new Grid{ColumnDefinitions={new ColumnDefinition(GridLength.Star),new ColumnDefinition(GridLength.Auto)}};header.Add(new VerticalStackLayout{Children={new Label{Text="شهبون لإدارة التراخيص",FontSize=27,FontAttributes=FontAttributes.Bold},new Label{Text="إدارة أكواد التفعيل وبيانات الزبائن",TextColor=LUi.Muted}}},0,0);header.Add(clock,1,0);
        Content=new ScrollView{Content=new VerticalStackLayout{Padding=18,Spacing=18,MaximumWidthRequest=900,HorizontalOptions=LayoutOptions.Center,Children={header,LUi.Card(new Label{Text="مفتاح التوقيع محمي ومربوط بكلمة مرور الجلسة.",TextColor=LUi.Muted}),grid}}};
        timer=Dispatcher.CreateTimer();timer.Interval=TimeSpan.FromSeconds(1);timer.Tick+=(_,_)=>clock.Text=DateTime.Now.ToString("HH:mm:ss\ndd/MM/yyyy");timer.Start();
    }
}
