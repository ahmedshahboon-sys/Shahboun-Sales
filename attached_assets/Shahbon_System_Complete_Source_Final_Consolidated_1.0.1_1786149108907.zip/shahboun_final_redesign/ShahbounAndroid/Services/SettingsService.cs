using ShahbounAndroid.Models;

namespace ShahbounAndroid.Services;

public sealed class SettingsService
{
    private readonly DatabaseService _database;
    public SettingsService(DatabaseService database) => _database = database;

    public async Task<string> GetAsync(string key, string defaultValue = "")
    {
        var row = await _database.Db.FindAsync<AppSetting>(key);
        return row?.Value ?? defaultValue;
    }

    public async Task SetAsync(string key, string value)
    {
        await _database.Db.InsertOrReplaceAsync(new AppSetting { Key = key, Value = value });
    }
}
