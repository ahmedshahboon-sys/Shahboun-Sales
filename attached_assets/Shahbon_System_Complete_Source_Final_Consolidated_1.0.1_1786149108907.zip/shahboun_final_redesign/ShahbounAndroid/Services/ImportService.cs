using System.Data;
using System.Globalization;
using ExcelDataReader;
using ShahbounAndroid.Models;

namespace ShahbounAndroid.Services;

public sealed class ImportService
{
    private readonly DatabaseService _database;
    public ImportService(DatabaseService database) => _database = database;

    public async Task<(int Added, int Updated, int Skipped)> ImportProductsAsync(Stream stream, string filename)
    {
        var rows = filename.EndsWith(".csv", StringComparison.OrdinalIgnoreCase)
            ? ReadCsv(stream)
            : ReadExcel(stream);

        if (rows.Count == 0) return (0, 0, 0);
        var headers = rows[0].Select(Normalize).ToList();
        int added = 0, updated = 0, skipped = 0;

        for (int r = 1; r < rows.Count; r++)
        {
            var row = rows[r];
            string Get(params string[] names)
            {
                foreach (var n in names)
                {
                    var idx = headers.FindIndex(h => h == Normalize(n));
                    if (idx >= 0 && idx < row.Count) return row[idx]?.Trim() ?? "";
                }
                return "";
            }

            var name = Get("اسم المنتج", "المنتج", "name", "item", "product");
            var barcode = Get("باركود", "barcode", "code", "sku");
            if (string.IsNullOrWhiteSpace(name)) { skipped++; continue; }

            decimal Parse(string s) => decimal.TryParse(s, NumberStyles.Any, CultureInfo.InvariantCulture, out var v)
                || decimal.TryParse(s, NumberStyles.Any, CultureInfo.CurrentCulture, out v) ? v : 0;

            var existing = !string.IsNullOrWhiteSpace(barcode)
                ? await _database.Db.Table<Product>().Where(x => x.Barcode == barcode).FirstOrDefaultAsync()
                : await _database.Db.Table<Product>().Where(x => x.Name == name).FirstOrDefaultAsync();

            var p = existing ?? new Product();
            p.Name = name;
            p.Barcode = barcode;
            p.PurchasePriceLyd = Parse(Get("سعر الشراء", "purchase", "cost"));
            p.SalePrice = Parse(Get("سعر البيع", "sale", "price", "retail"));
            p.Quantity = Parse(Get("الكمية", "quantity", "qty", "stock"));
            p.Unit = Get("الوحدة", "unit") is { Length: > 0 } unit ? unit : "قطعة";
            p.PartNumber = Get("رقم القطعة", "part number", "partnumber");
            p.VehicleCompatibility = Get("التوافق", "vehicle", "compatibility");

            if (existing is null) { await _database.Db.InsertAsync(p); added++; }
            else { await _database.Db.UpdateAsync(p); updated++; }
        }
        return (added, updated, skipped);
    }

    private static List<List<string>> ReadCsv(Stream stream)
    {
        using var reader = new StreamReader(stream, leaveOpen: true);
        var result = new List<List<string>>();
        while (!reader.EndOfStream)
        {
            var line = reader.ReadLine() ?? "";
            result.Add(ParseCsvLine(line));
        }
        return result;
    }

    private static List<string> ParseCsvLine(string line)
    {
        var cells = new List<string>();
        var current = new System.Text.StringBuilder();
        bool quoted = false;
        for (int i = 0; i < line.Length; i++)
        {
            var c = line[i];
            if (c == '"')
            {
                if (quoted && i + 1 < line.Length && line[i + 1] == '"') { current.Append('"'); i++; }
                else quoted = !quoted;
            }
            else if (c == ',' && !quoted) { cells.Add(current.ToString()); current.Clear(); }
            else current.Append(c);
        }
        cells.Add(current.ToString());
        return cells;
    }

    private static List<List<string>> ReadExcel(Stream stream)
    {
        System.Text.Encoding.RegisterProvider(System.Text.CodePagesEncodingProvider.Instance);
        using var reader = ExcelReaderFactory.CreateReader(stream);
        var ds = reader.AsDataSet();
        var table = ds.Tables[0];
        var result = new List<List<string>>();
        foreach (DataRow dr in table.Rows)
            result.Add(dr.ItemArray.Select(x => x?.ToString() ?? "").ToList());
        return result;
    }

    private static string Normalize(string value) =>
        new string(value.Trim().ToLowerInvariant().Where(char.IsLetterOrDigit).ToArray());
}
