using System.Text.Json;

namespace ShahbounAndroid.Services;

public sealed class UpdateInfo
{
    public int VersionCode { get; set; }
    public string VersionName { get; set; } = "";
    public string DownloadUrl { get; set; } = "";
    public bool Required { get; set; }
    public string NotesAr { get; set; } = "";
}

public sealed class UpdateService
{
    readonly HttpClient _http = new() { Timeout = TimeSpan.FromSeconds(15) };
    readonly SettingsService _settings;
    public UpdateService(SettingsService settings) => _settings = settings;

    public async Task<UpdateInfo?> CheckAsync()
    {
        var url = await _settings.GetAsync("UpdateManifestUrl", "");
        if (string.IsNullOrWhiteSpace(url)) return null;
        var json = await _http.GetStringAsync(url);
        return JsonSerializer.Deserialize<UpdateInfo>(json, new JsonSerializerOptions { PropertyNameCaseInsensitive = true });
    }
}
