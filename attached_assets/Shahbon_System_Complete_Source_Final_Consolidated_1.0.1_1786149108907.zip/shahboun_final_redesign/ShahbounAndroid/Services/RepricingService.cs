using ShahbounAndroid.Models;

namespace ShahbounAndroid.Services;

public sealed record RepricingPreview(int ProductId, string ProductName, decimal OldCostLyd, decimal NewCostLyd, decimal OldSalePrice, decimal NewSalePrice);

public sealed class RepricingService(DatabaseService database, SettingsService settings)
{
    public async Task<IReadOnlyList<RepricingPreview>> PreviewAsync(decimal newRate, decimal marginPercent, decimal roundTo)
    {
        if (newRate <= 0) throw new ArgumentOutOfRangeException(nameof(newRate));
        var products = await database.Db.Table<Product>().Where(p => p.IsActive && p.PurchasePriceUsd > 0).ToListAsync();
        var result = new List<RepricingPreview>(products.Count);
        foreach (var p in products)
        {
            var newCost = decimal.Round(p.PurchasePriceUsd * newRate, 2, MidpointRounding.AwayFromZero);
            var rawSale = newCost * (1m + marginPercent / 100m);
            var newSale = Round(rawSale, roundTo);
            result.Add(new RepricingPreview(p.Id, p.Name, p.PurchasePriceLyd, newCost, p.SalePrice, newSale));
        }
        return result;
    }

    public async Task ApplyAsync(decimal newRate, decimal marginPercent, decimal roundTo, string changedBy)
    {
        var oldText = await settings.GetAsync("UsdRate", "1");
        _ = decimal.TryParse(oldText, System.Globalization.NumberStyles.Any, System.Globalization.CultureInfo.InvariantCulture, out var oldRate);
        var preview = await PreviewAsync(newRate, marginPercent, roundTo);
        await database.Db.RunInTransactionAsync(connection =>
        {
            foreach (var row in preview)
            {
                var product = connection.Find<Product>(row.ProductId);
                if (product is null) continue;
                product.PurchasePriceLyd = row.NewCostLyd;
                product.SalePrice = row.NewSalePrice;
                connection.Update(product);
            }
            connection.Insert(new ExchangeRateHistory
            {
                ChangedAtUtc = DateTime.UtcNow,
                OldRate = oldRate,
                NewRate = newRate,
                ChangedBy = changedBy,
                PricesRecalculated = true,
                Notes = $"هامش {marginPercent}%، تقريب {roundTo}"
            });
        });
        await settings.SetAsync("UsdRate", newRate.ToString(System.Globalization.CultureInfo.InvariantCulture));
    }

    static decimal Round(decimal value, decimal step)
    {
        if (step <= 0) return decimal.Round(value, 2, MidpointRounding.AwayFromZero);
        return decimal.Round(value / step, 0, MidpointRounding.AwayFromZero) * step;
    }
}
