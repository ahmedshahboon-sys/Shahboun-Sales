using ShahbounAndroid.Models;

namespace ShahbounAndroid.Services;

public sealed class BranchWarehouseService
{
    readonly DatabaseService _database;
    public BranchWarehouseService(DatabaseService database) => _database = database;

    public Task<List<Branch>> GetBranchesAsync() => _database.Db.Table<Branch>().Where(x => x.IsActive).ToListAsync();
    public Task<List<Warehouse>> GetWarehousesAsync(int branchId) => _database.Db.Table<Warehouse>().Where(x => x.BranchId == branchId && x.IsActive).ToListAsync();

    public async Task TransferAsync(int fromWarehouseId, int toWarehouseId, int productId, decimal quantity, string username)
    {
        if (fromWarehouseId == toWarehouseId) throw new InvalidOperationException("يجب اختيار مستودعين مختلفين.");
        if (quantity <= 0) throw new ArgumentOutOfRangeException(nameof(quantity));
        var from = await GetStockAsync(fromWarehouseId, productId);
        if (from.Quantity < quantity) throw new InvalidOperationException("الكمية المتوفرة غير كافية.");
        var to = await GetStockAsync(toWarehouseId, productId);
        await _database.Db.RunInTransactionAsync(conn =>
        {
            from.Quantity -= quantity; to.Quantity += quantity;
            conn.Update(from); conn.InsertOrReplace(to);
            var transfer = new StockTransfer { CreatedAtUtc = DateTime.UtcNow, FromWarehouseId = fromWarehouseId, ToWarehouseId = toWarehouseId, Reference = $"TR-{DateTime.UtcNow:yyyyMMddHHmmss}", CreatedBy = username };
            conn.Insert(transfer);
            conn.Insert(new StockTransferItem { TransferId = transfer.Id, ProductId = productId, Quantity = quantity });
        });
    }

    async Task<WarehouseStock> GetStockAsync(int warehouseId, int productId) =>
        await _database.Db.Table<WarehouseStock>().Where(x => x.WarehouseId == warehouseId && x.ProductId == productId).FirstOrDefaultAsync()
        ?? new WarehouseStock { WarehouseId = warehouseId, ProductId = productId, Quantity = 0 };
}
