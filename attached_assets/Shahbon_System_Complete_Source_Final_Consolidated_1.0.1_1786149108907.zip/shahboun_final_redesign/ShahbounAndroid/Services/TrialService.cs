using ShahbounAndroid.Models;

namespace ShahbounAndroid.Services;

public sealed class TrialService
{
    private readonly DatabaseService _database;
    private static readonly TimeSpan TrialLength = TimeSpan.FromHours(24);

    public TrialService(DatabaseService database) => _database = database;

    public async Task<TrialRecord?> GetAsync() => await _database.Db.FindAsync<TrialRecord>(1);

    public async Task<TrialRecord> StartAsync()
    {
        var existing = await GetAsync();
        if (existing is not null && existing.IsStarted) return existing;

        var now = DateTime.UtcNow;
        var trial = new TrialRecord
        {
            Id = 1,
            StartedAtUtc = now,
            ExpiresAtUtc = now.Add(TrialLength),
            IsStarted = true,
            IsLocked = false
        };
        await _database.Db.InsertOrReplaceAsync(trial);
        return trial;
    }

    public async Task<bool> IsActiveAsync()
    {
        var trial = await GetAsync();
        if (trial is null || !trial.IsStarted) return false;
        if (trial.IsLocked) return false;
        if (DateTime.UtcNow <= trial.ExpiresAtUtc) return true;
        trial.IsLocked = true;
        await _database.Db.UpdateAsync(trial);
        return false;
    }

    public async Task<TimeSpan> RemainingAsync()
    {
        var trial = await GetAsync();
        if (trial is null || !trial.IsStarted) return TimeSpan.Zero;
        var remaining = trial.ExpiresAtUtc - DateTime.UtcNow;
        return remaining > TimeSpan.Zero ? remaining : TimeSpan.Zero;
    }
}
