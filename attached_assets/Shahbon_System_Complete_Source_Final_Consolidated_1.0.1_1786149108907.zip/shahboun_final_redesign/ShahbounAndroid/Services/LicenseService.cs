using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using ShahbounAndroid.Models;

namespace ShahbounAndroid.Services;

public sealed class LicenseService
{
    private readonly DatabaseService _database;
    private const string PublicKeyPem = """
-----BEGIN PUBLIC KEY-----
MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAxqToZYvSVH7rsXvVDJ+n
vyCm7x5KRfrd1j4AHi99S8etdZ3MCAIWucaDRYJpxWF+yUU8zilX4iifFb4H+U/r
VwbKDOvExomvfcaUnelR/uN2AMQMpHGs8vsGTV+xHawXWKxMP9Hdf+9QYjIOLhJ9
dfe//4ErL7nWkHb6cB+/FaS1OsXGJlkDw2x3HcbbpST9Fsrh6QUw/4SVXbZOD3ol
4pVCuncxjdXEFpgGAxNQdWCkfL8y8WrLZCKTQgaSKZvI+Vmqdk36Pmn2OZjce1H5
g4VfOS/Ffh7EZ/KcxVzuNq4el/V7ErP/q9yyoB65N9AgtGk8RBTOgedLAbmlhRwf
BwIDAQAB
-----END PUBLIC KEY-----
""";

    public LicenseService(DatabaseService database) => _database = database;

    public string DeviceCode => DeviceIdentityService.GetDeviceCode();

    public bool IsActivated()
    {
        var record = _database.Db.FindAsync<ActivationRecord>(1).GetAwaiter().GetResult();
        return record is not null &&
               string.Equals(record.DeviceCode, DeviceCode, StringComparison.OrdinalIgnoreCase) &&
               Verify(record.LicenseCode, out _);
    }

    public bool TryActivate(string licenseCode, out string message)
    {
        if (!Verify(licenseCode.Trim(), out var payload))
        {
            message = "سيريال التفعيل غير صحيح.";
            return false;
        }

        if (!string.Equals(payload!.DeviceCode, DeviceCode, StringComparison.OrdinalIgnoreCase))
        {
            message = "السيريال لا يخص هذا الجهاز.";
            return false;
        }

        _database.Db.InsertOrReplaceAsync(new ActivationRecord
        {
            Id = 1,
            DeviceCode = DeviceCode,
            LicenseCode = licenseCode.Trim(),
            ActivatedAt = DateTime.Now
        }).GetAwaiter().GetResult();

        message = "تم تفعيل المنظومة مدى الحياة.";
        return true;
    }

    private static bool Verify(string licenseCode, out LicensePayload? payload)
    {
        payload = null;
        try
        {
            var parts = licenseCode.Split('.');
            if (parts.Length != 2) return false;
            var data = Base64UrlDecode(parts[0]);
            var signature = Base64UrlDecode(parts[1]);

            using var rsa = RSA.Create();
            rsa.ImportFromPem(PublicKeyPem);
            if (!rsa.VerifyData(data, signature, HashAlgorithmName.SHA256, RSASignaturePadding.Pkcs1))
                return false;

            payload = JsonSerializer.Deserialize<LicensePayload>(data);
            return payload is not null &&
                   payload.Product == "SHAHBOUN-ANDROID" &&
                   payload.Lifetime;
        }
        catch { return false; }
    }

    private static byte[] Base64UrlDecode(string input)
    {
        var s = input.Replace('-', '+').Replace('_', '/');
        s += new string('=', (4 - s.Length % 4) % 4);
        return Convert.FromBase64String(s);
    }

    public sealed class LicensePayload
    {
        public string Product { get; set; } = "";
        public string DeviceCode { get; set; } = "";
        public bool Lifetime { get; set; }
        public DateTime IssuedAtUtc { get; set; }
        public string CustomerName { get; set; } = "";
    }
}
