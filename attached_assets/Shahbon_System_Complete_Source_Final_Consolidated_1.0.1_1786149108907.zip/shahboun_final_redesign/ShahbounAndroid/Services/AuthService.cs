using ShahbounAndroid.Models;

namespace ShahbounAndroid.Services;

public sealed class AuthService
{
    private readonly DatabaseService _database;
    public UserAccount? CurrentUser { get; private set; }

    private const string TechnicalUsername = "shahboun";
    private const string TechnicalSalt = "pLB+mtfTRvuL5vSogdy2og==";
    private const string TechnicalHash = "P/p6WojGUqupaYArRqsOcgAlqSg4VLRWv5hKisPdtZc=";

    public AuthService(DatabaseService database) => _database = database;

    public async Task<(bool Success, bool MustChange, string Message)> LoginAsync(string username, string password)
    {
        username = username.Trim().ToLowerInvariant();

        if (username == TechnicalUsername &&
            PasswordHasher.Verify(password, TechnicalHash, TechnicalSalt))
        {
            CurrentUser = new UserAccount
            {
                Id = -1,
                Username = TechnicalUsername,
                IsAdmin = true,
                PermissionsCsv = "*",
                IsActive = true
            };
            await LogAsync("دخول تقني", "تم الدخول بالحساب التقني الكامل.");
            return (true, false, "");
        }

        var user = await _database.Db.Table<UserAccount>()
            .Where(x => x.Username == username)
            .FirstOrDefaultAsync();

        if (user is null || !user.IsActive)
            return (false, false, "بيانات الدخول غير صحيحة.");

        if (!PasswordHasher.Verify(password, user.PasswordHash, user.PasswordSalt))
            return (false, false, "بيانات الدخول غير صحيحة.");

        CurrentUser = user;
        await LogAsync("تسجيل دخول", $"دخل المستخدم {username}.");
        return (true, user.MustChangePassword, "");
    }

    public async Task ChangeCurrentCredentialsAsync(string newUsername, string newPassword)
    {
        if (CurrentUser is null || CurrentUser.Id <= 0)
            throw new InvalidOperationException("لا يوجد مستخدم قابل للتعديل.");

        var existing = await _database.Db.Table<UserAccount>()
            .Where(x => x.Username == newUsername && x.Id != CurrentUser.Id)
            .FirstOrDefaultAsync();
        if (existing is not null)
            throw new InvalidOperationException("اسم المستخدم مستخدم مسبقاً.");

        var (hash, salt) = PasswordHasher.Hash(newPassword);
        CurrentUser.Username = newUsername.Trim().ToLowerInvariant();
        CurrentUser.PasswordHash = hash;
        CurrentUser.PasswordSalt = salt;
        CurrentUser.MustChangePassword = false;
        await _database.Db.UpdateAsync(CurrentUser);
        await LogAsync("تغيير بيانات المدير", "تم تغيير اسم المستخدم وكلمة المرور الإجباريين.");
    }

    public bool HasPermission(string permission)
    {
        if (CurrentUser is null) return false;
        if (CurrentUser.IsAdmin || CurrentUser.PermissionsCsv == "*") return true;
        return CurrentUser.PermissionsCsv.Split(',', StringSplitOptions.RemoveEmptyEntries)
            .Contains(permission, StringComparer.OrdinalIgnoreCase);
    }

    public async Task LogAsync(string action, string details)
    {
        await _database.Db.InsertAsync(new AuditLog
        {
            CreatedAt = DateTime.Now,
            Username = CurrentUser?.Username ?? "SYSTEM",
            Action = action,
            Details = details
        });
    }

    public void Logout() => CurrentUser = null;
}
