using QRCoder;

namespace ShahbounAndroid.Services;

public sealed class QrPaymentService
{
    public byte[] CreatePng(string bank, string holder, string account, decimal amount, string invoice)
    {
        var payload = $"SHAHBOUN|BANK={bank}|HOLDER={holder}|ACCOUNT={account}|AMOUNT={amount:0.00}|INVOICE={invoice}";
        using var generator = new QRCodeGenerator();
        using var data = generator.CreateQrCode(payload, QRCodeGenerator.ECCLevel.Q);
        var qr = new PngByteQRCode(data);
        return qr.GetGraphic(12);
    }
}
