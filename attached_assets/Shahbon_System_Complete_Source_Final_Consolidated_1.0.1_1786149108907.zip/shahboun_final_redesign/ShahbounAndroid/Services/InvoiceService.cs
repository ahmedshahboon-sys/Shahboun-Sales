using System.Net;
using System.Text;
using ShahbounAndroid.Models;

namespace ShahbounAndroid.Services;

public sealed class InvoiceService
{
    readonly DatabaseService _database;
    readonly SettingsService _settings;
    public InvoiceService(DatabaseService database, SettingsService settings) { _database = database; _settings = settings; }

    public async Task<string> CreateHtmlAsync(int saleId)
    {
        var sale = await _database.Db.FindAsync<Sale>(saleId) ?? throw new InvalidOperationException("الفاتورة غير موجودة.");
        var items = await _database.Db.Table<SaleItem>().Where(x => x.SaleId == saleId).ToListAsync();
        var business = await _settings.GetAsync("BusinessName", "منظومة شهبون");
        var phone = await _settings.GetAsync("Phone", "");
        var address = await _settings.GetAsync("Address", "ليبيا");
        var footer = await _settings.GetAsync("InvoiceFooter", "شكراً لزيارتكم");
        var logoPath = await _settings.GetAsync("StoreLogoPath", "");
        var logo = "";
        if (File.Exists(logoPath))
        {
            var bytes = await File.ReadAllBytesAsync(logoPath);
            logo = $"<img class='logo' src='data:image/png;base64,{Convert.ToBase64String(bytes)}'/>";
        }
        var rows = string.Join("", items.Select((x, i) => $"<tr><td>{i + 1}</td><td>{WebUtility.HtmlEncode(x.ProductName)}</td><td>{x.Quantity:0.##}</td><td>{x.UnitPrice:0.00}</td><td>{x.Total:0.00}</td></tr>"));
        var html = $"""
<!doctype html><html lang='ar' dir='rtl'><head><meta charset='utf-8'><meta name='viewport' content='width=device-width'><style>
body{{font-family:Arial,sans-serif;margin:24px;color:#14213d}} .head{{text-align:center}} .logo{{max-height:90px;max-width:180px}} table{{width:100%;border-collapse:collapse;margin-top:18px}} th,td{{border:1px solid #bbb;padding:8px;text-align:center}} th{{background:#071B36;color:white}} .totals{{margin-top:18px;font-size:18px}} .footer{{margin-top:30px;text-align:center;color:#555}} @media print{{button{{display:none}} body{{margin:5mm}}}}
</style></head><body><div class='head'>{logo}<h1>{WebUtility.HtmlEncode(business)}</h1><div>{WebUtility.HtmlEncode(address)} — {WebUtility.HtmlEncode(phone)}</div><h2>فاتورة مبيعات رقم {WebUtility.HtmlEncode(sale.InvoiceNumber)}</h2><div>{sale.CreatedAt:yyyy/MM/dd HH:mm}</div></div>
<table><thead><tr><th>#</th><th>الصنف</th><th>الكمية</th><th>السعر</th><th>الإجمالي</th></tr></thead><tbody>{rows}</tbody></table>
<div class='totals'><div>الإجمالي الفرعي: {sale.Subtotal:0.00}</div><div>الخصم: {sale.Discount:0.00}</div><strong>الإجمالي النهائي: {sale.Total:0.00}</strong><div>المدفوع: {sale.Paid:0.00}</div><div>طريقة الدفع: {WebUtility.HtmlEncode(sale.PaymentMethod)}</div></div>
<div class='footer'>{WebUtility.HtmlEncode(footer)}<br/>جميع الحقوق محفوظة — المبرمج أحمد شهبون</div><script>window.print=function(){{}}</script></body></html>
""";
        var path = Path.Combine(FileSystem.CacheDirectory, $"Invoice_{sale.InvoiceNumber}.html");
        await File.WriteAllTextAsync(path, html, Encoding.UTF8);
        return path;
    }
}
