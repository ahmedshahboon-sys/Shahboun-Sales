#if ANDROID
using Android.App;
using Android.Content;
using Android.OS;
#endif

namespace ShahbounAndroid.Services;

public sealed class NotificationService
{
    private const string ChannelId = "shahboun_important";
    private const string ChannelName = "تنبيهات منظومة شهبون";

    public void Initialize()
    {
#if ANDROID
        if (Build.VERSION.SdkInt < BuildVersionCodes.O) return;
        var context = Android.App.Application.Context;
        var manager = context.GetSystemService(Context.NotificationService) as NotificationManager;
        if (manager is null || manager.GetNotificationChannel(ChannelId) is not null) return;
        var channel = new NotificationChannel(ChannelId, ChannelName, NotificationImportance.High)
        {
            Description = "تنبيهات المخزون والديون والنسخ الاحتياطي والتحديثات"
        };
        manager.CreateNotificationChannel(channel);
#endif
    }

    public void Show(string title, string message, int id = 1001)
    {
#if ANDROID
        try
        {
            Initialize();
            var context = Android.App.Application.Context;
            Notification.Builder builder;
            if (Build.VERSION.SdkInt >= BuildVersionCodes.O) builder = new Notification.Builder(context, ChannelId);
            else
            {
#pragma warning disable CS0618
                builder = new Notification.Builder(context);
#pragma warning restore CS0618
            }
            builder.SetContentTitle(string.IsNullOrWhiteSpace(title) ? "منظومة شهبون" : title)
                .SetContentText(string.IsNullOrWhiteSpace(message) ? "يوجد تنبيه جديد." : message)
                .SetSmallIcon(Android.Resource.Drawable.IcDialogInfo)
                .SetAutoCancel(true)
                .SetOnlyAlertOnce(true);
            var manager = context.GetSystemService(Context.NotificationService) as NotificationManager;
            manager?.Notify(id, builder.Build());
        }
        catch { }
#endif
    }
}
