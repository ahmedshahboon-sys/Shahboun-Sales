using System.Security.Cryptography;
using System.Text;

namespace ShahbounAndroid.Services;

public static class DeviceIdentityService
{
    public static string GetDeviceCode()
    {
#if ANDROID
        var context = Android.App.Application.Context;
        var androidId = Android.Provider.Settings.Secure.GetString(
            context.ContentResolver,
            Android.Provider.Settings.Secure.AndroidId) ?? "unknown";
        var source = $"{androidId}|{DeviceInfo.Manufacturer}|{DeviceInfo.Model}|SHAHBOUN";
#else
        var source = $"{DeviceInfo.Manufacturer}|{DeviceInfo.Model}|SHAHBOUN";
#endif
        var bytes = SHA256.HashData(Encoding.UTF8.GetBytes(source));
        var compact = Convert.ToHexString(bytes)[..20];
        return string.Join("-", Enumerable.Range(0, 4).Select(i => compact.Substring(i * 5, 5)));
    }
}
