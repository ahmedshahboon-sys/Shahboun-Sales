using SQLite;
using ShahbounAndroid.Models;

namespace ShahbounAndroid.Services;

public sealed class DatabaseService
{
    private SQLiteAsyncConnection? _db;
    public SQLiteAsyncConnection Db => _db ?? throw new InvalidOperationException("Database not initialized.");
    public string DatabasePath { get; private set; } = "";

    public async Task InitializeAsync()
    {
        if (_db is not null) return;
        DatabasePath = Path.Combine(FileSystem.AppDataDirectory, "shahboun_android.db3");
        _db = new SQLiteAsyncConnection(DatabasePath, SQLiteOpenFlags.ReadWrite | SQLiteOpenFlags.Create | SQLiteOpenFlags.SharedCache);

        await Db.CreateTableAsync<AppSetting>(); await Db.CreateTableAsync<UserAccount>(); await Db.CreateTableAsync<Category>();
        await Db.CreateTableAsync<Product>(); await Db.CreateTableAsync<Customer>(); await Db.CreateTableAsync<Supplier>();
        await Db.CreateTableAsync<Sale>(); await Db.CreateTableAsync<SaleItem>(); await Db.CreateTableAsync<Purchase>(); await Db.CreateTableAsync<PurchaseItem>();
        await Db.CreateTableAsync<StockMovement>(); await Db.CreateTableAsync<Expense>(); await Db.CreateTableAsync<CashTransaction>();
        await Db.CreateTableAsync<CustomerPayment>(); await Db.CreateTableAsync<SupplierPayment>(); await Db.CreateTableAsync<ReturnRecord>();
        await Db.CreateTableAsync<EcommerceOrder>(); await Db.CreateTableAsync<AuditLog>(); await Db.CreateTableAsync<ActivationRecord>();
        await Db.CreateTableAsync<TrialRecord>(); await Db.CreateTableAsync<BusinessProfile>(); await Db.CreateTableAsync<ExchangeRateHistory>();
        await Db.CreateTableAsync<PaymentAccount>(); await Db.CreateTableAsync<TransferPayment>();
        await Db.CreateTableAsync<Branch>(); await Db.CreateTableAsync<Warehouse>(); await Db.CreateTableAsync<WarehouseStock>();
        await Db.CreateTableAsync<StockTransfer>(); await Db.CreateTableAsync<StockTransferItem>(); await Db.CreateTableAsync<WorkShift>();
        await Db.CreateTableAsync<Role>(); await Db.CreateTableAsync<UserRole>(); await Db.CreateTableAsync<DatabaseMigration>();

        if (await Db.Table<UserAccount>().CountAsync() == 0)
        {
            var (hash, salt) = PasswordHasher.Hash("admin");
            await Db.InsertAsync(new UserAccount { Username = "admin", PasswordHash = hash, PasswordSalt = salt, IsAdmin = true, MustChangePassword = true, PermissionsCsv = "*" });
        }
        if (await Db.Table<Branch>().CountAsync() == 0)
        {
            var branch = new Branch { Name = "الفرع الرئيسي", IsMain = true, IsActive = true };
            await Db.InsertAsync(branch);
            await Db.InsertAsync(new Warehouse { BranchId = branch.Id, Name = "المستودع الرئيسي", IsActive = true });
        }
        if (await Db.Table<Role>().CountAsync() == 0)
        {
            await Db.InsertAllAsync(new[]
            {
                new Role { Name = "مدير النظام", PermissionsCsv = "*", IsSystem = true },
                new Role { Name = "موظف مبيعات", PermissionsCsv = "pos,sales,customers", IsSystem = true },
                new Role { Name = "أمين مخزن", PermissionsCsv = "products,inventory,purchases,returns", IsSystem = true }
            });
        }
        if (await Db.FindAsync<DatabaseMigration>(1) is null)
            await Db.InsertAsync(new DatabaseMigration { Version = 1, AppliedAtUtc = DateTime.UtcNow, Description = "Initial complete schema" });

        if (await Db.Table<Category>().CountAsync() == 0)
        {
            await Db.InsertAllAsync(new[] { new Category { Name = "عام" }, new Category { Name = "مواد غذائية" }, new Category { Name = "قطع غيار" }, new Category { Name = "أدوية" }, new Category { Name = "متجر إلكتروني" } });
        }
    }
}
