namespace ShahbounAndroid.Services;
public sealed class ThemeService
{
    readonly SettingsService settings;
    public ThemeService(SettingsService settings)=>this.settings=settings;
    public async Task ApplyAsync(string? theme=null,string? mode=null)
    {
        theme??=await settings.GetAsync("ThemeName","classic");mode??=await settings.GetAsync("ThemeMode","system");
        await settings.SetAsync("ThemeName",theme);await settings.SetAsync("ThemeMode",mode);
        if(Application.Current is null)return;
        Application.Current.UserAppTheme=mode switch{"light"=>AppTheme.Light,"dark"=>AppTheme.Dark,_=>AppTheme.Unspecified};
        var dark=Application.Current.RequestedTheme==AppTheme.Dark||mode=="dark";
        var p=theme switch{"blue"=>("#0B2A4A","#168AAD","#E63946","#F2F7FA","#FFFFFF","#C8D8E4","#557080"),"luxury"=>("#242424","#B58B38","#A63D40","#F6F3ED","#FFFFFF","#DED5C5","#746B5F"),_=>("#071B36","#08A66C","#E31B23","#F4F7FA","#FFFFFF","#DDE5ED","#667085")};
        Application.Current.Resources["Primary"]=Color.FromArgb(p.Item1);Application.Current.Resources["Accent"]=Color.FromArgb(p.Item2);Application.Current.Resources["Danger"]=Color.FromArgb(p.Item3);Application.Current.Resources["PageSurface"]=dark?Color.FromArgb("#101418"):Color.FromArgb(p.Item4);Application.Current.Resources["CardSurface"]=dark?Color.FromArgb("#1B2229"):Color.FromArgb(p.Item5);Application.Current.Resources["LineColor"]=dark?Color.FromArgb("#34404A"):Color.FromArgb(p.Item6);Application.Current.Resources["MutedText"]=dark?Color.FromArgb("#AAB6C1"):Color.FromArgb(p.Item7);Application.Current.Resources["MainText"]=dark?Colors.White:Color.FromArgb(p.Item1);
    }
}
