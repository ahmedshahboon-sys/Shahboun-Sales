using System.IO.Compression;

namespace ShahbounAndroid.Services;

public sealed class BackupService
{
    readonly DatabaseService _database;
    public BackupService(DatabaseService database) => _database = database;

    public async Task<string> CreateAsync(bool cache = true)
    {
        await AppServices.InitializeAsync();
        var dir = cache ? FileSystem.CacheDirectory : FileSystem.AppDataDirectory;
        var path = Path.Combine(dir, $"ShahbounBackup_{DateTime.Now:yyyyMMdd_HHmmss}.zip");
        if (File.Exists(path)) File.Delete(path);
        using var archive = ZipFile.Open(path, ZipArchiveMode.Create);
        archive.CreateEntryFromFile(_database.DatabasePath, "shahboun_android.db3", CompressionLevel.Optimal);
        var manifest = archive.CreateEntry("manifest.txt");
        await using var stream = manifest.Open();
        await using var writer = new StreamWriter(stream);
        await writer.WriteAsync($"Shahboun Backup\nCreated={DateTime.UtcNow:O}\nVersion=0.8.0\n");
        return path;
    }

    public async Task RestoreAsync(string zipPath)
    {
        if (!File.Exists(zipPath)) throw new FileNotFoundException("ملف النسخة غير موجود.");
        var safety = await CreateAsync(false);
        using var archive = ZipFile.OpenRead(zipPath);
        var db = archive.GetEntry("shahboun_android.db3") ?? throw new InvalidDataException("الملف لا يحتوي قاعدة بيانات صالحة.");
        var temp = Path.Combine(FileSystem.CacheDirectory, "restore_shahboun.db3");
        db.ExtractToFile(temp, true);
        if (new FileInfo(temp).Length < 1024) throw new InvalidDataException("قاعدة البيانات داخل النسخة غير صالحة.");
        File.Copy(temp, _database.DatabasePath, true);
        await AppServices.Settings.SetAsync("LastSafetyBackup", safety);
    }
}
