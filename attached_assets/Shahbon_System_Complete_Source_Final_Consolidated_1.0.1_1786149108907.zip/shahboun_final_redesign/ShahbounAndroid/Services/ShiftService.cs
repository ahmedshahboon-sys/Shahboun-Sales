using ShahbounAndroid.Models;

namespace ShahbounAndroid.Services;

public sealed class ShiftService
{
    readonly DatabaseService _database;
    public ShiftService(DatabaseService database) => _database = database;
    public Task<WorkShift?> GetOpenAsync(int userId) => _database.Db.Table<WorkShift>().Where(x => x.UserId == userId && x.Status == "مفتوحة").FirstOrDefaultAsync();
    public async Task<WorkShift> OpenAsync(int userId, int branchId, decimal openingCash)
    {
        if (await GetOpenAsync(userId) is not null) throw new InvalidOperationException("لدى المستخدم وردية مفتوحة.");
        var shift = new WorkShift { UserId = userId, BranchId = branchId, OpenedAtUtc = DateTime.UtcNow, OpeningCash = openingCash };
        await _database.Db.InsertAsync(shift); return shift;
    }
    public async Task CloseAsync(int shiftId, decimal closingCash, string notes)
    {
        var shift = await _database.Db.FindAsync<WorkShift>(shiftId) ?? throw new InvalidOperationException("الوردية غير موجودة.");
        shift.ClosedAtUtc = DateTime.UtcNow; shift.ClosingCash = closingCash; shift.Status = "مغلقة"; shift.Notes = notes;
        await _database.Db.UpdateAsync(shift);
    }
}
