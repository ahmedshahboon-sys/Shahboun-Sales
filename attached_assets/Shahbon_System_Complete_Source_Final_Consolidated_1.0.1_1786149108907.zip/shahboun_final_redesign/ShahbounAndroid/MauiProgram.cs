using ZXing.Net.Maui.Controls;
using ShahbounAndroid.Services;

namespace ShahbounAndroid;

public static class MauiProgram
{
    public static MauiApp CreateMauiApp()
    {
        var builder = MauiApp.CreateBuilder();
        builder.UseMauiApp<App>()
            .UseBarcodeReader();

        var app = builder.Build();
        AppServices.Configure(app.Services);
        return app;
    }
}

public static class AppServices
{
    private static bool _initialized;
    private static readonly SemaphoreSlim InitLock = new(1, 1);

    public static DatabaseService Database { get; private set; } = null!;
    public static LicenseService LicenseService { get; private set; } = null!;
    public static AuthService Auth { get; private set; } = null!;
    public static SettingsService Settings { get; private set; } = null!;
    public static TrialService Trial { get; private set; } = null!;
    public static ThemeService Theme { get; private set; } = null!;
    public static RepricingService Repricing { get; private set; } = null!;
    public static NotificationService Notifications { get; private set; } = null!;
    public static BackupService Backup { get; private set; } = null!;
    public static UpdateService Updates { get; private set; } = null!;
    public static QrPaymentService QrPayments { get; private set; } = null!;
    public static InvoiceService Invoices { get; private set; } = null!;
    public static BranchWarehouseService Branches { get; private set; } = null!;
    public static ShiftService Shifts { get; private set; } = null!;

    public static void Configure(IServiceProvider provider)
    {
        Database = new DatabaseService();
        Settings = new SettingsService(Database);
        LicenseService = new LicenseService(Database);
        Auth = new AuthService(Database);
        Trial = new TrialService(Database);
        Theme = new ThemeService(Settings);
        Repricing = new RepricingService(Database, Settings);
        Backup = new BackupService(Database);
        Updates = new UpdateService(Settings);
        QrPayments = new QrPaymentService();
        Invoices = new InvoiceService(Database, Settings);
        Branches = new BranchWarehouseService(Database);
        Shifts = new ShiftService(Database);
        Notifications = new NotificationService();
        Notifications.Initialize();
    }

    public static async Task InitializeAsync()
    {
        if (_initialized) return;

        await InitLock.WaitAsync();
        try
        {
            if (_initialized) return;
            await Database.InitializeAsync();
            _initialized = true;
        }
        finally
        {
            InitLock.Release();
        }
    }
}
