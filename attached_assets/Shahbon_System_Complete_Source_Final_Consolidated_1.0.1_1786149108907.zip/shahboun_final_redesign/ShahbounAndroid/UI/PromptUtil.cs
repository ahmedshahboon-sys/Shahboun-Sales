namespace ShahbounAndroid.UI;

public static class PromptUtil
{
    public static async Task<decimal?> DecimalAsync(Page page, string title, string message, string initial = "0")
    {
        var text = await page.DisplayPromptAsync(title, message, initialValue: initial, keyboard: Keyboard.Numeric);
        if (string.IsNullOrWhiteSpace(text)) return null;
        text = text.Replace(',', '.');
        return decimal.TryParse(text, System.Globalization.NumberStyles.Any, System.Globalization.CultureInfo.InvariantCulture, out var value) ? value : null;
    }

    public static Label Small(string text) => new() { Text = text, TextColor = Colors.DimGray, FontSize = 13 };
}
