namespace ShahbounAndroid.UI;

public static class Ui
{
    public static Color Navy => Get("Primary", "#071B36");
    public static Color Green => Get("Accent", "#08A66C");
    public static Color Red => Get("Danger", "#E31B23");
    public static Color Gold => Get("Gold", "#D4A84E");
    public static Color Surface => Get("PageSurface", "#F6F8FB");
    public static Color CardSurface => Get("CardSurface", "#FFFFFF");
    public static Color Border => Get("LineColor", "#E4EAF0");
    public static Color Muted => Get("MutedText", "#728095");
    public static Color Text => Get("MainText", "#071B36");

    static Color Get(string key, string fallback) =>
        Application.Current?.Resources.TryGetValue(key, out var value) == true && value is Color color
            ? color : Color.FromArgb(fallback);

    public static Label Title(string text) => new()
    {
        Text = text,
        FontSize = 27,
        FontAttributes = FontAttributes.Bold,
        TextColor = Text,
        HorizontalTextAlignment = TextAlignment.End,
        FlowDirection = FlowDirection.RightToLeft
    };

    public static Label Subtitle(string text) => new()
    {
        Text = text,
        FontSize = 13,
        TextColor = Muted,
        HorizontalTextAlignment = TextAlignment.End,
        FlowDirection = FlowDirection.RightToLeft
    };

    public static Entry Entry(string placeholder, bool password = false) => new()
    {
        Placeholder = placeholder,
        IsPassword = password,
        FlowDirection = FlowDirection.RightToLeft,
        ClearButtonVisibility = ClearButtonVisibility.WhileEditing,
        TextColor = Text,
        PlaceholderColor = Muted,
        BackgroundColor = CardSurface
    };

    public static Button Primary(string text) => Button(text, Navy);
    public static Button Success(string text) => Button(text, Green);
    public static Button Danger(string text) => Button(text, Red);

    static Button Button(string text, Color color) => new()
    {
        Text = text,
        BackgroundColor = color,
        TextColor = Colors.White,
        FontAttributes = FontAttributes.Bold,
        CornerRadius = 15,
        HeightRequest = 54
    };

    public static Border Card(View content, Thickness? padding = null, double radius = 20) => new()
    {
        BackgroundColor = CardSurface,
        Stroke = Border,
        StrokeThickness = 1,
        Padding = padding ?? new Thickness(16),
        StrokeShape = new Microsoft.Maui.Controls.Shapes.RoundRectangle { CornerRadius = radius },
        Shadow = new Shadow { Brush = Brush.Black, Opacity = .07f, Radius = 12, Offset = new Point(0, 4) },
        Content = content
    };

    public static Border ModuleCard(string icon, string title, string subtitle, EventHandler tapped)
    {
        var image = new Image { Source = icon, HeightRequest = 54, WidthRequest = 54, HorizontalOptions = LayoutOptions.Center };
        var titleLabel = new Label
        {
            Text = title,
            FontSize = 17,
            FontAttributes = FontAttributes.Bold,
            TextColor = Text,
            HorizontalTextAlignment = TextAlignment.Center
        };
        var subtitleLabel = new Label
        {
            Text = subtitle,
            FontSize = 11,
            TextColor = Muted,
            HorizontalTextAlignment = TextAlignment.Center,
            MaxLines = 2
        };
        var footer = new Grid { ColumnDefinitions = { new ColumnDefinition(GridLength.Star), new ColumnDefinition(GridLength.Auto) } };
        footer.Add(new Label { Text = "خيارات", FontSize = 11, TextColor = Muted }, 0, 0);
        footer.Add(new Label { Text = "•••", FontSize = 17, TextColor = Muted }, 1, 0);
        var stack = new VerticalStackLayout { Spacing = 7, Children = { image, titleLabel, subtitleLabel, new BoxView { HeightRequest = 1, Color = Border }, footer } };
        var card = Card(stack, new Thickness(14), 18);
        card.HeightRequest = 190;
        var tap = new TapGestureRecognizer();
        tap.Tapped += tapped;
        card.GestureRecognizers.Add(tap);
        return card;
    }

    public static async Task Alert(Page page, string title, string message) =>
        await page.DisplayAlertAsync(title, message, "حسناً");
}
