using ShahbounAndroid.UI;

namespace ShahbounAndroid.Pages;

public sealed class SettingsPage : ContentPage
{
    readonly Entry _business=Ui.Entry("اسم النشاط"), _phone=Ui.Entry("رقم الهاتف"), _address=Ui.Entry("العنوان"), _currency=Ui.Entry("العملة"), _exchange=Ui.Entry("سعر صرف الدولار"), _footer=Ui.Entry("نص أسفل الفاتورة"), _tax=Ui.Entry("نسبة الضريبة %"), _thermalIp=Ui.Entry("IP الطابعة الحرارية"), _thermalPort=Ui.Entry("منفذ الطابعة (عادة 9100)");
    readonly Image _logoPreview = new() { HeightRequest = 110, Aspect = Aspect.AspectFit };
    readonly Label _logoStatus = new() { Text = "لم يتم اختيار شعار", FontSize = 12, TextColor = Ui.Muted };
    readonly Picker _activity=new(){Title="نوع النشاط",ItemsSource=new[]{"تجاري عام","مواد غذائية","صيدلية","قطع غيار سيارات","ملابس","مستحضرات تجميل","إلكترونيات","متجر إلكتروني"}};
    readonly Picker _paper=new(){Title="مقاس الورق الحراري",ItemsSource=new[]{"58mm","80mm"}};
    readonly Picker _theme=new(){Title="ألوان التطبيق",ItemsSource=new[]{"شهبون الكلاسيكي","الأزرق الاحترافي","الرمادي الفاخر"}};
    readonly Picker _mode=new(){Title="وضع العرض",ItemsSource=new[]{"تلقائي حسب الهاتف","فاتح","مظلم"}};
    public SettingsPage()
    {
        Title="الإعدادات والطباعة";
        var save=Ui.Primary("حفظ الإعدادات"); save.Clicked+=async(_,_)=>await SaveAsync();
        var chooseLogo=Ui.Success("اختيار شعار من الصور"); chooseLogo.Clicked+=async(_,_)=>await PickLogoAsync();
        var takeLogo=Ui.Primary("تصوير شعار بالكاميرا"); takeLogo.Clicked+=async(_,_)=>await CaptureLogoAsync();
        var testNotice=Ui.Primary("اختبار إشعارات الهاتف"); testNotice.Clicked+=(_,_)=>AppServices.Notifications.Show("منظومة شهبون","الإشعارات تعمل بنجاح.");
        var applyTheme=Ui.Success("تطبيق الثيم الآن");applyTheme.Clicked+=async(_,_)=>{var t=_theme.SelectedIndex switch{1=>"blue",2=>"luxury",_=>"classic"};var m=_mode.SelectedIndex switch{1=>"light",2=>"dark",_=>"system"};await AppServices.Theme.ApplyAsync(t,m);Application.Current!.Windows[0].Page=new NavigationPage(new DashboardPage());};
        Content=new ScrollView{Content=new VerticalStackLayout{Padding=16,Spacing=10,MaximumWidthRequest=760,HorizontalOptions=LayoutOptions.Center,Children={new Image{Source="shahboun_logo.png",HeightRequest=85,Aspect=Aspect.AspectFit},Ui.Title("بيانات المنشأة"),Ui.Card(new VerticalStackLayout{Spacing=8,Children={_logoPreview,_logoStatus,chooseLogo,takeLogo}}),_business,_phone,_address,_activity,_currency,_exchange,_tax,_footer,Ui.Card(new VerticalStackLayout{Spacing=10,Children={new Label{Text="المظهر والثيم",FontSize=20,FontAttributes=FontAttributes.Bold},_theme,_mode,applyTheme}}),new Label{Text="إعداد الطابعة الحرارية",FontSize=20,FontAttributes=FontAttributes.Bold,TextColor=Ui.Navy},_paper,_thermalIp,_thermalPort,PromptUtil.Small("طباعة A4 تستخدم شاشة الطباعة الرسمية في أندرويد. الربط الفعلي بالطابعة الحرارية يحتاج اختبار موديل الطابعة على الهاتف."),testNotice,save}}};
    }

    async Task PickLogoAsync()
    {
        var result = await FilePicker.Default.PickAsync(new PickOptions { PickerTitle = "اختر شعار المتجر", FileTypes = FilePickerFileType.Images });
        if (result is null) return;
        await SaveLogoAsync(result.FullPath);
    }

    async Task CaptureLogoAsync()
    {
        if (!MediaPicker.Default.IsCaptureSupported) { await Ui.Alert(this, "غير متاح", "الكاميرا غير متاحة على هذا الجهاز."); return; }
        var result = await MediaPicker.Default.CapturePhotoAsync();
        if (result is null) return;
        await SaveLogoAsync(result.FullPath);
    }

    async Task SaveLogoAsync(string sourcePath)
    {
        var ext = Path.GetExtension(sourcePath);
        var target = Path.Combine(FileSystem.AppDataDirectory, "store_logo" + (string.IsNullOrWhiteSpace(ext) ? ".png" : ext));
        File.Copy(sourcePath, target, true);
        await AppServices.Settings.SetAsync("StoreLogoPath", target);
        _logoPreview.Source = ImageSource.FromFile(target);
        _logoStatus.Text = "تم حفظ شعار المتجر وسيستخدم في الفواتير.";
    }

    async Task SaveAsync()
    {
        await AppServices.Settings.SetAsync("BusinessName",_business.Text??""); await AppServices.Settings.SetAsync("Phone",_phone.Text??""); await AppServices.Settings.SetAsync("Address",_address.Text??""); await AppServices.Settings.SetAsync("ActivityType",_activity.SelectedItem?.ToString()??"تجاري عام"); await AppServices.Settings.SetAsync("Currency",_currency.Text??"د.ل"); await AppServices.Settings.SetAsync("UsdRate",_exchange.Text??"1"); await AppServices.Settings.SetAsync("TaxRate",_tax.Text??"0"); await AppServices.Settings.SetAsync("InvoiceFooter",_footer.Text??"شكراً لزيارتكم"); await AppServices.Settings.SetAsync("ThermalPaper",_paper.SelectedItem?.ToString()??"80mm"); await AppServices.Settings.SetAsync("ThermalIp",_thermalIp.Text??""); await AppServices.Settings.SetAsync("ThermalPort",_thermalPort.Text??"9100"); await Ui.Alert(this,"تم","تم حفظ بيانات المنشأة والطباعة.");
    }
    protected override async void OnAppearing()
    {
        base.OnAppearing();
        _business.Text=await AppServices.Settings.GetAsync("BusinessName","متجري");_phone.Text=await AppServices.Settings.GetAsync("Phone","");_address.Text=await AppServices.Settings.GetAsync("Address","ليبيا");_currency.Text=await AppServices.Settings.GetAsync("Currency","د.ل");_exchange.Text=await AppServices.Settings.GetAsync("UsdRate","1");_tax.Text=await AppServices.Settings.GetAsync("TaxRate","0");_footer.Text=await AppServices.Settings.GetAsync("InvoiceFooter","شكراً لزيارتكم");_thermalIp.Text=await AppServices.Settings.GetAsync("ThermalIp","");_thermalPort.Text=await AppServices.Settings.GetAsync("ThermalPort","9100");
        var logo=await AppServices.Settings.GetAsync("StoreLogoPath",""); if(File.Exists(logo)){_logoPreview.Source=ImageSource.FromFile(logo);_logoStatus.Text="تم تحميل شعار المتجر.";}
        var act=await AppServices.Settings.GetAsync("ActivityType","تجاري عام");_activity.SelectedIndex=Array.IndexOf((string[])_activity.ItemsSource,act);var paper=await AppServices.Settings.GetAsync("ThermalPaper","80mm");_paper.SelectedIndex=paper=="58mm"?0:1;
        _theme.SelectedIndex=(await AppServices.Settings.GetAsync("ThemeName","classic")) switch{"blue"=>1,"luxury"=>2,_=>0};_mode.SelectedIndex=(await AppServices.Settings.GetAsync("ThemeMode","system")) switch{"light"=>1,"dark"=>2,_=>0};
    }
}
