using ShahbounAndroid.UI;

namespace ShahbounAndroid.Pages;

public sealed class BackupPage : ContentPage
{
    readonly Label _status = new() { TextColor = Ui.Muted };
    public BackupPage()
    {
        Title = "النسخ الاحتياطي والاستعادة";
        var export = Ui.Primary("إنشاء نسخة ومشاركتها"); export.Clicked += async (_, _) => await ExportAsync();
        var local = Ui.Success("حفظ نسخة محلية"); local.Clicked += async (_, _) => await LocalAsync();
        var restore = Ui.Danger("استعادة نسخة"); restore.Clicked += async (_, _) => await RestoreAsync();
        Content = new ScrollView { Content = new VerticalStackLayout { Padding = 18, Spacing = 14, MaximumWidthRequest = 720, HorizontalOptions = LayoutOptions.Center, Children = { Ui.Title("حماية بياناتك"), PromptUtil.Small("النسخة ZIP تحتوي قاعدة البيانات كاملة. قبل الاستعادة تُنشأ نسخة أمان تلقائية، ثم يلزم إعادة تشغيل التطبيق."), export, local, restore, _status } } };
    }
    async Task ExportAsync()
    {
        try { var path = await AppServices.Backup.CreateAsync(); await Share.Default.RequestAsync(new ShareFileRequest { Title = "نسخة احتياطية لمنظومة شهبون", File = new ShareFile(path) }); _status.Text = "تم إنشاء النسخة وفتح المشاركة."; }
        catch (Exception ex) { await Ui.Alert(this, "تعذر النسخ", ex.Message); }
    }
    async Task LocalAsync()
    {
        try { var path = await AppServices.Backup.CreateAsync(false); _status.Text = $"تم الحفظ:\n{path}"; }
        catch (Exception ex) { await Ui.Alert(this, "تعذر النسخ", ex.Message); }
    }
    async Task RestoreAsync()
    {
        var file = await FilePicker.Default.PickAsync(new PickOptions { PickerTitle = "اختر نسخة ShahbounBackup", FileTypes = new FilePickerFileType(new Dictionary<DevicePlatform, IEnumerable<string>> { [DevicePlatform.Android] = new[] { "application/zip", "application/octet-stream" } }) });
        if (file is null) return;
        var confirm = await DisplayAlert("تأكيد الاستعادة", "سيتم استبدال البيانات الحالية بعد إنشاء نسخة أمان. هل أنت متأكد؟", "استعادة", "إلغاء");
        if (!confirm) return;
        try { await AppServices.Backup.RestoreAsync(file.FullPath); await DisplayAlert("تمت الاستعادة", "أغلق التطبيق وافتحه من جديد.", "حسنًا"); }
        catch (Exception ex) { await Ui.Alert(this, "فشلت الاستعادة", ex.Message); }
    }
}
