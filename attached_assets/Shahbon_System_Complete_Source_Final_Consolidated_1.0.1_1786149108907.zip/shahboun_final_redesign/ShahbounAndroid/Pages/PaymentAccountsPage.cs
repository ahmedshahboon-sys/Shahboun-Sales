using ShahbounAndroid.Models;
using ShahbounAndroid.UI;

namespace ShahbounAndroid.Pages;

public sealed class PaymentAccountsPage : ContentPage
{
    readonly VerticalStackLayout _list = new() { Spacing = 10 };
    public PaymentAccountsPage()
    {
        Title = "الحوالات وQR";
        var add = Ui.Success("إضافة حساب مصرفي"); add.Clicked += async (_, _) => await AddAsync();
        Content = new ScrollView { Content = new VerticalStackLayout { Padding = 16, Spacing = 12, Children = { Ui.Title("حسابات الدفع والتحويل"), PromptUtil.Small("الحوالة لا تعتمد تلقائيًا. تحفظ كقيد مراجعة إلى أن يوافق المدير."), add, _list } } };
    }
    protected override async void OnAppearing() { base.OnAppearing(); await LoadAsync(); }
    async Task LoadAsync()
    {
        _list.Children.Clear();
        var rows = await AppServices.Database.Db.Table<PaymentAccount>().Where(x => x.IsActive).ToListAsync();
        foreach (var x in rows)
        {
            var qr = Ui.Primary("عرض QR"); qr.Clicked += async (_, _) => await ShowQrAsync(x);
            var del = Ui.Danger("إيقاف"); del.Clicked += async (_, _) => { x.IsActive = false; await AppServices.Database.Db.UpdateAsync(x); await LoadAsync(); };
            _list.Children.Add(Ui.Card(new VerticalStackLayout { Spacing = 6, Children = { new Label { Text = x.BankName, FontSize = 19, FontAttributes = FontAttributes.Bold }, new Label { Text = $"{x.AccountHolder}\n{x.AccountNumber}\n{x.BranchName}" }, qr, del } }));
        }
    }
    async Task AddAsync()
    {
        var bank = await DisplayPromptAsync("الحساب", "اسم المصرف"); if (string.IsNullOrWhiteSpace(bank)) return;
        var holder = await DisplayPromptAsync("الحساب", "اسم صاحب الحساب"); if (string.IsNullOrWhiteSpace(holder)) return;
        var number = await DisplayPromptAsync("الحساب", "رقم الحساب أو LYPay"); if (string.IsNullOrWhiteSpace(number)) return;
        var branch = await DisplayPromptAsync("الحساب", "الفرع (اختياري)") ?? "";
        await AppServices.Database.Db.InsertAsync(new PaymentAccount { BankName = bank, AccountHolder = holder, AccountNumber = number, BranchName = branch });
        await LoadAsync();
    }
    async Task ShowQrAsync(PaymentAccount account)
    {
        var amountText = await DisplayPromptAsync("قيمة الحوالة", "أدخل المبلغ", keyboard: Keyboard.Numeric);
        decimal.TryParse(amountText, out var amount);
        var invoice = await DisplayPromptAsync("رقم الفاتورة", "اختياري") ?? "";
        var bytes = AppServices.QrPayments.CreatePng(account.BankName, account.AccountHolder, account.AccountNumber, amount, invoice);
        var path = Path.Combine(FileSystem.CacheDirectory, $"payment_qr_{account.Id}.png"); await File.WriteAllBytesAsync(path, bytes);
        var image = new Image { Source = ImageSource.FromFile(path), HeightRequest = 300 };
        var share = Ui.Success("مشاركة QR"); share.Clicked += async (_, _) => await Share.Default.RequestAsync(new ShareFileRequest { Title = "QR الدفع", File = new ShareFile(path) });
        await Navigation.PushAsync(new ContentPage { Title = "QR الدفع", Content = new ScrollView { Content = new VerticalStackLayout { Padding = 18, Spacing = 12, Children = { image, new Label { Text = $"{account.BankName}\n{account.AccountHolder}\n{account.AccountNumber}\nالمبلغ: {amount:0.00}", HorizontalTextAlignment = TextAlignment.Center }, share } } } });
    }
}
