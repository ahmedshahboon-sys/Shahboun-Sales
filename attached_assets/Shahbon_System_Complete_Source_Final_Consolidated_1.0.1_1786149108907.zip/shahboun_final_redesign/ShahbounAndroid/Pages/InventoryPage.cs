using ShahbounAndroid.Models;
using ShahbounAndroid.UI;

namespace ShahbounAndroid.Pages;

public sealed class InventoryPage : ContentPage
{
    readonly Entry _search = Ui.Entry("بحث بالاسم أو الباركود");
    readonly VerticalStackLayout _list = new() { Spacing = 8 };
    public InventoryPage()
    {
        Title = "المخزون والجرد"; BackgroundColor = Ui.Surface;
        _search.TextChanged += async (_,_) => await LoadAsync();
        Content = new ScrollView { Content = new VerticalStackLayout { Padding = 14, Spacing = 12, Children = { _search, _list } } };
    }
    protected override async void OnAppearing() { base.OnAppearing(); await LoadAsync(); }
    async Task LoadAsync()
    {
        _list.Clear(); var rows = await AppServices.Database.Db.Table<Product>().Where(x => x.IsActive).OrderBy(x => x.Name).ToListAsync();
        var q = (_search.Text ?? "").Trim(); if (q.Length > 0) rows = rows.Where(x => x.Name.Contains(q, StringComparison.OrdinalIgnoreCase) || x.Barcode.Contains(q)).ToList();
        foreach (var p in rows)
        {
            var button = new Button { Text = $"{p.Name}\nالمتوفر: {p.Quantity:0.###} {p.Unit} — الحد الأدنى: {p.MinimumStock:0.###}", BackgroundColor = p.Quantity <= p.MinimumStock ? Color.FromArgb("#FFF0F0") : Colors.White, TextColor = Ui.Navy };
            button.Clicked += async (_,_) =>
            {
                var action = await DisplayActionSheetAsync(p.Name, "إلغاء", null, "إضافة كمية", "خصم كمية", "تسوية الرصيد");
                if (action is null or "إلغاء") return;
                var value = await PromptUtil.DecimalAsync(this, action, "الكمية", p.Quantity.ToString()); if (value is null) return;
                decimal change;
                if (action == "إضافة كمية") { change = value.Value; p.Quantity += value.Value; }
                else if (action == "خصم كمية") { change = -value.Value; p.Quantity -= value.Value; }
                else { change = value.Value - p.Quantity; p.Quantity = value.Value; }
                await AppServices.Database.Db.UpdateAsync(p);
                await AppServices.Database.Db.InsertAsync(new StockMovement { ProductId = p.Id, ProductName = p.Name, QuantityChange = change, MovementType = action, CreatedAt = DateTime.Now });
                await LoadAsync();
            };
            _list.Add(button);
        }
    }
}
