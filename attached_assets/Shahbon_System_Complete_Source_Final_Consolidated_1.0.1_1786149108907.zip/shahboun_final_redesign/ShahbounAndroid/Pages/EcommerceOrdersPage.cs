using ShahbounAndroid.Models;
using ShahbounAndroid.UI;

namespace ShahbounAndroid.Pages;

public sealed class EcommerceOrdersPage : ContentPage
{
    readonly VerticalStackLayout _list = new() { Spacing = 8 };
    public EcommerceOrdersPage()
    {
        Title = "طلبات المتجر الإلكتروني"; BackgroundColor = Ui.Surface;
        var add = Ui.Primary("طلب جديد"); add.BackgroundColor = Ui.Green; add.Clicked += async (_,_) => await AddAsync();
        Content = new ScrollView { Content = new VerticalStackLayout { Padding = 14, Spacing = 12, Children = { add, _list } } };
    }
    protected override async void OnAppearing() { base.OnAppearing(); await LoadAsync(); }
    async Task LoadAsync()
    {
        _list.Clear(); foreach (var x in await AppServices.Database.Db.Table<EcommerceOrder>().OrderByDescending(x => x.Id).Take(100).ToListAsync())
        {
            var b = new Button { Text = $"#{x.Id} {x.CustomerName} — {x.Status}\n{x.Phone} / {x.City}\n{(x.ProductsTotal + x.DeliveryFee):0.000} د.ل — {x.Source}", BackgroundColor = Colors.White, TextColor = Ui.Navy };
            b.Clicked += async (_,_) =>
            {
                var status = await DisplayActionSheetAsync("تغيير حالة الطلب", "إلغاء", null, "جديد", "مؤكد", "قيد التجهيز", "خرج للتوصيل", "تم التسليم", "ملغي");
                if (status is null or "إلغاء") return; x.Status = status; await AppServices.Database.Db.UpdateAsync(x); await LoadAsync();
            };
            _list.Add(b);
        }
    }
    async Task AddAsync()
    {
        var name = await DisplayPromptAsync("طلب جديد", "اسم العميل"); if (string.IsNullOrWhiteSpace(name)) return;
        var phone = await DisplayPromptAsync("طلب جديد", "رقم الهاتف"); var city = await DisplayPromptAsync("طلب جديد", "المدينة والمنطقة");
        var source = await DisplayActionSheetAsync("مصدر الطلب", "إلغاء", null, "فيسبوك", "إنستغرام", "واتساب", "المتجر", "أخرى"); if (source is null or "إلغاء") return;
        var total = await PromptUtil.DecimalAsync(this, "طلب جديد", "قيمة المنتجات") ?? 0; var delivery = await PromptUtil.DecimalAsync(this, "طلب جديد", "تكلفة التوصيل") ?? 0;
        await AppServices.Database.Db.InsertAsync(new EcommerceOrder { CustomerName = name.Trim(), Phone = phone ?? "", City = city ?? "", Source = source, ProductsTotal = total, DeliveryFee = delivery, CreatedAt = DateTime.Now }); await LoadAsync();
    }
}
