using ShahbounAndroid.UI;

namespace ShahbounAndroid.Pages;

public sealed class LoginPage : ContentPage
{
    private readonly Entry _username = Ui.Entry("اسم المستخدم");
    private readonly Entry _password = Ui.Entry("كلمة المرور", true);

    public LoginPage()
    {
        Title = "تسجيل الدخول";
        BackgroundColor = Ui.Surface;
        NavigationPage.SetHasNavigationBar(this, false);

        var login = Ui.Primary("دخول");
        login.Clicked += async (_, _) =>
        {
            var result = await AppServices.Auth.LoginAsync(_username.Text ?? "", _password.Text ?? "");
            if (!result.Success) { await Ui.Alert(this, "تنبيه", result.Message); return; }

            Application.Current!.Windows[0].Page = new NavigationPage(
                result.MustChange ? new ChangeAdminCredentialsPage() : new DashboardPage());
        };

        Content = new Grid
        {
            Padding = 24,
            Children =
            {
                new ScrollView
                {
                    Content = new VerticalStackLayout
                    {
                        MaximumWidthRequest = 520,
                        HorizontalOptions = LayoutOptions.Center,
                        VerticalOptions = LayoutOptions.Center,
                        Spacing = 18,
                        Children =
                        {
                            new Image { Source = "shahboun_logo.png", HeightRequest = 140, Aspect = Aspect.AspectFit },
                            Ui.Title("تسجيل الدخول"),
                            Ui.Card(new VerticalStackLayout
                            {
                                Spacing = 14,
                                Children = { _username, _password, login }
                            }),
                            new Label { Text = "منظومة شهبون للمبيعات - ليبيا", HorizontalTextAlignment = TextAlignment.Center, TextColor = Colors.Gray }
                        }
                    }
                }
            }
        };
    }
}
