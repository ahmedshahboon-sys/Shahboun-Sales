using System.Collections.ObjectModel;
using ShahbounAndroid.Services;
using ShahbounAndroid.UI;

namespace ShahbounAndroid.Pages;

public sealed class ExchangeRatePage : ContentPage
{
    readonly Entry _rate = Ui.Entry("سعر الدولار الجديد");
    readonly Entry _margin = Ui.Entry("هامش الربح %");
    readonly Picker _round = new() { Title = "تقريب السعر", ItemsSource = new[] { "بدون تقريب", "0.50", "1", "5" }, SelectedIndex = 2 };
    readonly ObservableCollection<RepricingPreview> _rows = new();
    readonly CollectionView _list;

    public ExchangeRatePage()
    {
        Title = "سعر الدولار وإعادة التسعير";
        _rate.Keyboard = Keyboard.Numeric;
        _margin.Keyboard = Keyboard.Numeric;
        _list = new CollectionView
        {
            ItemsSource = _rows,
            EmptyView = new Label { Text = "اضغط معاينة لعرض المنتجات المرتبطة بالدولار.", HorizontalTextAlignment = TextAlignment.Center, Margin = 20 },
            ItemTemplate = new DataTemplate(() =>
            {
                var name = new Label { FontAttributes = FontAttributes.Bold, FontSize = 16 };
                name.SetBinding(Label.TextProperty, nameof(RepricingPreview.ProductName));
                var cost = new Label { FontSize = 13, TextColor = Ui.Muted };
                cost.SetBinding(Label.TextProperty, new Binding(path: nameof(RepricingPreview.NewCostLyd), stringFormat: "التكلفة الجديدة: {0:N2} د.ل"));
                var sale = new Label { FontSize = 14 };
                sale.SetBinding(Label.TextProperty, new Binding(path: nameof(RepricingPreview.NewSalePrice), stringFormat: "سعر البيع الجديد: {0:N2} د.ل"));
                return Ui.Card(new VerticalStackLayout { Spacing = 3, Children = { name, cost, sale } });
            })
        };
        var preview = Ui.Primary("معاينة الأسعار الجديدة");
        preview.Clicked += async (_, _) => await PreviewAsync();
        var apply = Ui.Success("اعتماد التغيير بموافقة المدير");
        apply.Clicked += async (_, _) => await ApplyAsync();
        Content = new Grid
        {
            RowDefinitions = { new RowDefinition(GridLength.Auto), new RowDefinition(GridLength.Star) },
            Children =
            {
                new ScrollView { Content = new VerticalStackLayout { Padding = 16, Spacing = 10, Children = { Ui.Title("إعادة التسعير الآمنة"), PromptUtil.Small("لن تتغير الفواتير القديمة. التغيير يطبق فقط بعد المعاينة وموافقة المدير."), _rate, _margin, _round, preview, apply } } },
                _list
            }
        };
        Grid.SetRow(_list, 1);
    }

    protected override async void OnAppearing()
    {
        base.OnAppearing();
        _rate.Text = await AppServices.Settings.GetAsync("UsdRate", "1");
        _margin.Text = await AppServices.Settings.GetAsync("DefaultMarginPercent", "25");
    }

    async Task PreviewAsync()
    {
        if (!TryRead(out var rate, out var margin, out var round)) return;
        var preview = await AppServices.Repricing.PreviewAsync(rate, margin, round);
        _rows.Clear();
        foreach (var row in preview) _rows.Add(row);
        await Ui.Alert(this, "المعاينة", $"تم تجهيز {preview.Count} منتج. لم يتم تعديل أي سعر بعد.");
    }

    async Task ApplyAsync()
    {
        if (AppServices.Auth.CurrentUser?.IsAdmin != true)
        {
            await Ui.Alert(this, "غير مسموح", "هذه العملية تحتاج موافقة المدير.");
            return;
        }
        if (!TryRead(out var rate, out var margin, out var round)) return;
        var ok = await DisplayAlert("تأكيد المدير", "سيتم تعديل تكلفة وسعر بيع المنتجات المرتبطة بالدولار. هل تعتمد التغيير؟", "اعتماد", "إلغاء");
        if (!ok) return;
        await AppServices.Repricing.ApplyAsync(rate, margin, round, AppServices.Auth.CurrentUser?.Username ?? "admin");
        await AppServices.Settings.SetAsync("DefaultMarginPercent", margin.ToString(System.Globalization.CultureInfo.InvariantCulture));
        await Ui.Alert(this, "تم", "تم اعتماد سعر الدولار وإعادة التسعير بنجاح.");
        await PreviewAsync();
    }

    bool TryRead(out decimal rate, out decimal margin, out decimal round)
    {
        var culture = System.Globalization.CultureInfo.InvariantCulture;
        if (!decimal.TryParse((_rate.Text ?? "").Replace(',', '.'), System.Globalization.NumberStyles.Any, culture, out rate) || rate <= 0)
        {
            margin = round = 0; _ = Ui.Alert(this, "خطأ", "أدخل سعر دولار صحيحًا."); return false;
        }
        if (!decimal.TryParse((_margin.Text ?? "0").Replace(',', '.'), System.Globalization.NumberStyles.Any, culture, out margin) || margin < 0)
        {
            round = 0; _ = Ui.Alert(this, "خطأ", "أدخل هامش ربح صحيحًا."); return false;
        }
        round = _round.SelectedIndex switch { 1 => 0.5m, 2 => 1m, 3 => 5m, _ => 0m };
        return true;
    }
}
