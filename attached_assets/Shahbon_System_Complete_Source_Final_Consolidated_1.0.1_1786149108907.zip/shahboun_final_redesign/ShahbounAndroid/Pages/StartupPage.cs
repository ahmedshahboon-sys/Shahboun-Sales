using ShahbounAndroid.UI;

namespace ShahbounAndroid.Pages;

public sealed class StartupPage : ContentPage
{
    private bool _started;

    public StartupPage()
    {
        NavigationPage.SetHasNavigationBar(this, false);
        BackgroundColor = Ui.Navy;

        Content = new Grid
        {
            Padding = 30,
            Children =
            {
                new VerticalStackLayout
                {
                    HorizontalOptions = LayoutOptions.Center,
                    VerticalOptions = LayoutOptions.Center,
                    Spacing = 20,
                    Children =
                    {
                        new Image
                        {
                            Source = "shahboun_logo.png",
                            HeightRequest = 160,
                            WidthRequest = 280,
                            Aspect = Aspect.AspectFit
                        },
                        new ActivityIndicator
                        {
                            IsRunning = true,
                            Color = Colors.White,
                            WidthRequest = 42,
                            HeightRequest = 42
                        },
                        new Label
                        {
                            Text = "جاري تجهيز المنظومة...",
                            TextColor = Colors.White,
                            HorizontalTextAlignment = TextAlignment.Center,
                            FontSize = 16
                        }
                    }
                }
            }
        };
    }

    protected override async void OnAppearing()
    {
        base.OnAppearing();
        if (_started) return;
        _started = true;

        try
        {
            await AppServices.InitializeAsync();
            Page nextPage;
            var profile = await AppServices.Database.Db.FindAsync<ShahbounAndroid.Models.BusinessProfile>(1);
            if (profile is null)
            {
                nextPage = new BusinessRegistrationPage();
            }
            else if (AppServices.LicenseService.IsActivated() || await AppServices.Trial.IsActiveAsync())
            {
                nextPage = new LoginPage();
            }
            else
            {
                nextPage = new ActivationPage();
            }

            Application.Current!.Windows[0].Page = new NavigationPage(nextPage);
        }
        catch (Exception ex)
        {
            await DisplayAlert("تعذر تشغيل المنظومة", ex.Message, "حسنًا");
            _started = false;
        }
    }
}
