using ShahbounAndroid.Models;
using ShahbounAndroid.UI;

namespace ShahbounAndroid.Pages;

public sealed class ReportsPage : ContentPage
{
    readonly VerticalStackLayout _content = new() { Spacing = 12 };
    public ReportsPage() { Title = "التقارير"; BackgroundColor = Ui.Surface; Content = new ScrollView { Content = new VerticalStackLayout { Padding = 16, Children = { Ui.Title("ملخص النشاط"), _content } } }; }
    protected override async void OnAppearing()
    {
        base.OnAppearing(); _content.Clear(); var today = DateTime.Today;
        var sales = await AppServices.Database.Db.Table<Sale>().ToListAsync(); var items = await AppServices.Database.Db.Table<SaleItem>().ToListAsync(); var products = await AppServices.Database.Db.Table<Product>().ToListAsync();
        var expenses = await AppServices.Database.Db.Table<Expense>().ToListAsync(); var purchases = await AppServices.Database.Db.Table<Purchase>().ToListAsync(); var customers = await AppServices.Database.Db.Table<Customer>().ToListAsync(); var suppliers = await AppServices.Database.Db.Table<Supplier>().ToListAsync();
        var todaySales = sales.Where(x=>x.CreatedAt>=today).Sum(x=>x.Total); var monthSales = sales.Where(x=>x.CreatedAt.Year==today.Year && x.CreatedAt.Month==today.Month).Sum(x=>x.Total);
        var grossProfit = items.Sum(x => (x.UnitPrice-x.CostPrice)*x.Quantity); var monthExpenses = expenses.Where(x=>x.CreatedAt.Year==today.Year && x.CreatedAt.Month==today.Month).Sum(x=>x.Amount);
        var data = new[]
        {
            ("مبيعات اليوم",$"{todaySales:0.000} د.ل"),("مبيعات الشهر",$"{monthSales:0.000} د.ل"),("الربح الإجمالي التقديري",$"{grossProfit:0.000} د.ل"),
            ("مصروفات الشهر",$"{monthExpenses:0.000} د.ل"),("صافي تقديري",$"{(grossProfit-monthExpenses):0.000} د.ل"),("قيمة المخزون",$"{products.Sum(x=>x.Quantity*x.PurchasePriceLyd):0.000} د.ل"),
            ("مشتريات الشهر",$"{purchases.Where(x=>x.CreatedAt.Year==today.Year&&x.CreatedAt.Month==today.Month).Sum(x=>x.Total):0.000} د.ل"),("ديون العملاء",$"{customers.Sum(x=>x.Balance):0.000} د.ل"),
            ("ديون الموردين",$"{suppliers.Sum(x=>x.Balance):0.000} د.ل"),("منتجات ناقصة",products.Count(x=>x.Quantity<=x.MinimumStock).ToString()),("منتجات منتهية/قريبة",products.Count(x=>x.ExpiryDate!=null&&x.ExpiryDate<=today.AddDays(60)).ToString())
        };
        foreach(var x in data)
        {
            var g=new Grid { ColumnDefinitions={new ColumnDefinition(GridLength.Star),new ColumnDefinition(GridLength.Auto)} }; g.Add(new Label{Text=x.Item1,TextColor=Ui.Navy,FontAttributes=FontAttributes.Bold},0,0); g.Add(new Label{Text=x.Item2,TextColor=Ui.Red,FontSize=19,FontAttributes=FontAttributes.Bold},1,0); _content.Add(Ui.Card(g));
        }
        var top = items.GroupBy(x=>x.ProductName).Select(g=>new { Name=g.Key, Qty=g.Sum(x=>x.Quantity), Total=g.Sum(x=>x.Total)}).OrderByDescending(x=>x.Qty).Take(5).ToList();
        _content.Add(new Label{Text="الأكثر مبيعاً",FontSize=20,FontAttributes=FontAttributes.Bold,TextColor=Ui.Navy});
        foreach(var x in top) _content.Add(Ui.Card(new Label{Text=$"{x.Name} — {x.Qty:0.###} — {x.Total:0.000} د.ل",TextColor=Ui.Navy}));
    }
}
