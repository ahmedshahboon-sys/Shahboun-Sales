using ShahbounAndroid.Models;
using ShahbounAndroid.UI;

namespace ShahbounAndroid.Pages;

public sealed class PurchasesPage : ContentPage
{
    readonly VerticalStackLayout _list = new() { Spacing = 8 };
    public PurchasesPage()
    {
        Title = "المشتريات"; BackgroundColor = Ui.Surface;
        var add = Ui.Primary("فاتورة شراء سريعة"); add.BackgroundColor = Ui.Green; add.Clicked += async (_,_) => await AddAsync();
        Content = new ScrollView { Content = new VerticalStackLayout { Padding = 14, Spacing = 12, Children = { add, _list } } };
    }
    protected override async void OnAppearing() { base.OnAppearing(); await LoadAsync(); }
    async Task LoadAsync()
    {
        _list.Clear(); foreach (var x in await AppServices.Database.Db.Table<Purchase>().OrderByDescending(x => x.Id).Take(100).ToListAsync())
            _list.Add(Ui.Card(new Label { Text = $"{x.InvoiceNumber} — {x.CreatedAt:yyyy-MM-dd HH:mm}\nالإجمالي: {x.Total:0.000} — المدفوع: {x.Paid:0.000}", TextColor = Ui.Navy }));
    }
    async Task AddAsync()
    {
        var products = await AppServices.Database.Db.Table<Product>().Where(x => x.IsActive).OrderBy(x => x.Name).ToListAsync();
        if (products.Count == 0) { await Ui.Alert(this, "لا توجد منتجات", "أضف منتجاً أولاً."); return; }
        var names = products.Take(60).Select(x => $"{x.Id}|{x.Name}").ToArray();
        var selected = await DisplayActionSheetAsync("اختيار المنتج", "إلغاء", null, names); if (selected is null or "إلغاء") return;
        var idText = selected.Split('|')[0]; if (!int.TryParse(idText, out var id)) return; var product = products.First(x => x.Id == id);
        var qty = await PromptUtil.DecimalAsync(this, "الكمية", "الكمية المشتراة", "1"); if (qty is null || qty <= 0) return;
        var cost = await PromptUtil.DecimalAsync(this, "التكلفة", "تكلفة الوحدة", product.PurchasePriceLyd.ToString()); if (cost is null) return;
        var paid = await PromptUtil.DecimalAsync(this, "المدفوع", "المبلغ المدفوع", (qty.Value * cost.Value).ToString()) ?? 0;
        var purchase = new Purchase { InvoiceNumber = $"PUR-{DateTime.Now:yyyyMMddHHmmss}", CreatedAt = DateTime.Now, Total = qty.Value * cost.Value, Paid = paid };
        await AppServices.Database.Db.InsertAsync(purchase);
        await AppServices.Database.Db.InsertAsync(new PurchaseItem { PurchaseId = purchase.Id, ProductId = product.Id, ProductName = product.Name, Quantity = qty.Value, UnitCost = cost.Value, Total = purchase.Total });
        product.Quantity += qty.Value; product.PurchasePriceLyd = cost.Value; await AppServices.Database.Db.UpdateAsync(product);
        await AppServices.Database.Db.InsertAsync(new StockMovement { ProductId = product.Id, ProductName = product.Name, QuantityChange = qty.Value, MovementType = "شراء", Reference = purchase.InvoiceNumber, CreatedAt = DateTime.Now });
        await AppServices.Database.Db.InsertAsync(new CashTransaction { Type = "سحب", Amount = paid, Description = $"شراء {purchase.InvoiceNumber}", CreatedAt = DateTime.Now, UserId = AppServices.Auth.CurrentUser?.Id ?? 0 });
        await LoadAsync();
    }
}
