using ShahbounAndroid.Services;
using ShahbounAndroid.UI;

namespace ShahbounAndroid.Pages;

public sealed class ImportProductsPage : ContentPage
{
    public ImportProductsPage()
    {
        Title = "استيراد المنتجات";
        BackgroundColor = Ui.Surface;
        var pick = Ui.Primary("اختيار ملف Excel أو CSV");
        pick.BackgroundColor = Ui.Green;
        pick.Clicked += async (_, _) =>
        {
            try
            {
                var file = await FilePicker.Default.PickAsync(new PickOptions
                {
                    PickerTitle = "اختر ملف المنتجات",
                    FileTypes = new FilePickerFileType(new Dictionary<DevicePlatform, IEnumerable<string>>
                    {
                        { DevicePlatform.Android, new[] { "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "application/vnd.ms-excel", "text/csv", "text/comma-separated-values" } }
                    })
                });
                if (file is null) return;
                await using var stream = await file.OpenReadAsync();
                var result = await new ImportService(AppServices.Database).ImportProductsAsync(stream, file.FileName);
                await Ui.Alert(this, "نتيجة الاستيراد", $"تمت الإضافة: {result.Added}\nتم التحديث: {result.Updated}\nتم التجاهل: {result.Skipped}");
            }
            catch (Exception ex) { await Ui.Alert(this, "خطأ", ex.Message); }
        };
        Content = new ScrollView
        {
            Content = new VerticalStackLayout
            {
                Padding = 22,
                Spacing = 16,
                MaximumWidthRequest = 700,
                HorizontalOptions = LayoutOptions.Center,
                Children =
                {
                    Ui.Title("استيراد المنتجات تلقائياً"),
                    new Label
                    {
                        Text = "يدعم ملفات XLSX وXLS وCSV. يتعرف على أعمدة شائعة مثل: اسم المنتج، الباركود، سعر الشراء، سعر البيع، الكمية، الوحدة، رقم القطعة والتوافق.",
                        FontSize = 16, TextColor = Colors.DimGray, HorizontalTextAlignment = TextAlignment.Center
                    },
                    pick,
                    Ui.Card(new Label
                    {
                        Text = "أفضل نتيجة تكون عندما يحتوي الصف الأول على أسماء الأعمدة. المنتجات المتطابقة بالباركود تُحدَّث تلقائياً.",
                        TextColor = Ui.Navy
                    })
                }
            }
        };
    }
}
