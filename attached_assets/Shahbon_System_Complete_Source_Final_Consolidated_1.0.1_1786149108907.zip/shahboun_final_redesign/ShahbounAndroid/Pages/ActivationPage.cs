using ShahbounAndroid.UI;

namespace ShahbounAndroid.Pages;

public sealed class ActivationPage : ContentPage
{
    private readonly Entry _license = Ui.Entry("أدخل سيريال التفعيل");

    public ActivationPage()
    {
        Title = "تفعيل المنظومة";
        BackgroundColor = Ui.Surface;
        NavigationPage.SetHasNavigationBar(this, false);

        var deviceCode = AppServices.LicenseService.DeviceCode;
        var copy = new Button { Text = "نسخ كود الجهاز", BackgroundColor = Ui.Green, TextColor = Colors.White };
        copy.Clicked += async (_, _) =>
        {
            await Clipboard.Default.SetTextAsync(deviceCode);
            await Ui.Alert(this, "تم", "تم نسخ كود الجهاز.");
        };

        var trial = new Button { Text = "بدء تجربة مجانية لمدة 24 ساعة", BackgroundColor = Ui.Navy, TextColor = Colors.White };
        trial.Clicked += async (_, _) =>
        {
            await AppServices.Trial.StartAsync();
            Application.Current!.Windows[0].Page = new NavigationPage(new LoginPage());
        };

        var activate = Ui.Primary("تفعيل مدى الحياة");
        activate.Clicked += (_, _) =>
        {
            if (AppServices.LicenseService.TryActivate(_license.Text ?? "", out var msg))
            {
                Ui.Alert(this, "نجح التفعيل", msg);
                Application.Current!.Windows[0].Page = new NavigationPage(new LoginPage());
            }
            else Ui.Alert(this, "تعذر التفعيل", msg);
        };

        Content = new ScrollView
        {
            Content = new VerticalStackLayout
            {
                Padding = new Thickness(24, 50),
                Spacing = 18,
                MaximumWidthRequest = 650,
                HorizontalOptions = LayoutOptions.Center,
                Children =
                {
                    new Image { Source = "shahboun_logo.png", HeightRequest = 130, Aspect = Aspect.AspectFit },
                    Ui.Title("تفعيل منظومة شهبون"),
                    new Label
                    {
                        Text = "أرسل كود الجهاز إلى مزود المنظومة، ثم أدخل سيريال التفعيل الذي يصدره لك.",
                        HorizontalTextAlignment = TextAlignment.Center,
                        TextColor = Colors.DimGray,
                        FontSize = 16
                    },
                    Ui.Card(new VerticalStackLayout
                    {
                        Spacing = 10,
                        Children =
                        {
                            new Label { Text = "كود الجهاز", FontAttributes = FontAttributes.Bold, TextColor = Ui.Navy },
                            new Label { Text = deviceCode, FontSize = 20, FontAttributes = FontAttributes.Bold,
                                HorizontalTextAlignment = TextAlignment.Center, TextColor = Ui.Red },
                            copy
                        }
                    }),
                    _license,
                    activate,
                    trial,
                    new Label { Text = "للحصول على كود تفعيل اتصل أو تواصل عبر واتساب: 0912992050 أو 0922992050", HorizontalTextAlignment = TextAlignment.Center, TextColor = Ui.Navy, FontAttributes = FontAttributes.Bold },
                    new Label { Text = "التفعيل أوفلاين بالكامل ومربوط بهذا الجهاز. بياناتك لا تُحذف بعد انتهاء التجربة.", HorizontalTextAlignment = TextAlignment.Center, TextColor = Colors.Gray }
                }
            }
        };
    }
}
