using ShahbounAndroid.UI;

namespace ShahbounAndroid.Pages;

public sealed class ChangeAdminCredentialsPage : ContentPage
{
    public ChangeAdminCredentialsPage()
    {
        NavigationPage.SetHasNavigationBar(this, false);
        BackgroundColor = Ui.Surface;
        var user = Ui.Entry("اسم المستخدم الجديد");
        var pass = Ui.Entry("كلمة المرور الجديدة", true);
        var confirm = Ui.Entry("تأكيد كلمة المرور", true);
        var save = Ui.Primary("حفظ والدخول");

        save.Clicked += async (_, _) =>
        {
            if (string.IsNullOrWhiteSpace(user.Text) || (pass.Text?.Length ?? 0) < 6)
            {
                await Ui.Alert(this, "تنبيه", "اكتب اسم مستخدم وكلمة مرور لا تقل عن 6 خانات.");
                return;
            }
            if (pass.Text != confirm.Text)
            {
                await Ui.Alert(this, "تنبيه", "كلمتا المرور غير متطابقتين.");
                return;
            }
            try
            {
                await AppServices.Auth.ChangeCurrentCredentialsAsync(user.Text!, pass.Text!);
                Application.Current!.Windows[0].Page = new NavigationPage(new DashboardPage());
            }
            catch (Exception ex) { await Ui.Alert(this, "خطأ", ex.Message); }
        };

        Content = new ScrollView
        {
            Content = new VerticalStackLayout
            {
                Padding = 28,
                Spacing = 16,
                MaximumWidthRequest = 560,
                HorizontalOptions = LayoutOptions.Center,
                VerticalOptions = LayoutOptions.Center,
                Children =
                {
                    Ui.Title("إنشاء حساب المدير"),
                    new Label { Text = "لأسباب أمنية يجب تغيير بيانات admin / 123456 قبل استخدام المنظومة.",
                        HorizontalTextAlignment = TextAlignment.Center, TextColor = Colors.DimGray },
                    Ui.Card(new VerticalStackLayout { Spacing = 12, Children = { user, pass, confirm, save } })
                }
            }
        };
    }
}
