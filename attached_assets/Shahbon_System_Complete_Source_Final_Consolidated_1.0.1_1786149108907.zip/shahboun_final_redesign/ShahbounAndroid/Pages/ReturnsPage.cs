using ShahbounAndroid.Models;
using ShahbounAndroid.UI;

namespace ShahbounAndroid.Pages;

public sealed class ReturnsPage : ContentPage
{
    readonly VerticalStackLayout _list = new() { Spacing = 8 };
    public ReturnsPage()
    {
        Title = "المرتجعات"; BackgroundColor = Ui.Surface;
        var add = Ui.Primary("تسجيل مرتجع"); add.BackgroundColor = Ui.Red; add.Clicked += async (_,_) => await AddAsync();
        Content = new ScrollView { Content = new VerticalStackLayout { Padding = 14, Spacing = 12, Children = { add, _list } } };
    }
    protected override async void OnAppearing() { base.OnAppearing(); await LoadAsync(); }
    async Task LoadAsync()
    {
        _list.Clear(); foreach (var x in await AppServices.Database.Db.Table<ReturnRecord>().OrderByDescending(x => x.Id).Take(100).ToListAsync())
            _list.Add(Ui.Card(new Label { Text = $"{x.CreatedAt:yyyy-MM-dd HH:mm} — مرتجع {x.ReturnType}\nمرجع: {x.ReferenceNumber}\n{x.Amount:0.000} د.ل — {x.Reason}", TextColor = Ui.Navy }));
    }
    async Task AddAsync()
    {
        var type = await DisplayActionSheetAsync("نوع المرتجع", "إلغاء", null, "بيع", "شراء"); if (type is null or "إلغاء") return;
        var reference = await DisplayPromptAsync("مرتجع", "رقم الفاتورة أو المرجع");
        var amount = await PromptUtil.DecimalAsync(this, "مرتجع", "القيمة"); if (amount is null) return;
        var reason = await DisplayPromptAsync("مرتجع", "السبب");
        await AppServices.Database.Db.InsertAsync(new ReturnRecord { ReturnType = type, ReferenceNumber = reference ?? "", Amount = amount.Value, Reason = reason ?? "", CreatedAt = DateTime.Now });
        await AppServices.Database.Db.InsertAsync(new CashTransaction { Type = type == "بيع" ? "سحب" : "إيداع", Amount = amount.Value, Description = $"مرتجع {type} {reference}", CreatedAt = DateTime.Now, UserId = AppServices.Auth.CurrentUser?.Id ?? 0 }); await LoadAsync();
    }
}
