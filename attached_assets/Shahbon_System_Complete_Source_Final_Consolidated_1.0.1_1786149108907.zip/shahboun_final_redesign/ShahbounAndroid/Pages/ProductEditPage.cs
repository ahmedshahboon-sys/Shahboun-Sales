using ShahbounAndroid.Models;
using ShahbounAndroid.UI;

namespace ShahbounAndroid.Pages;

public sealed class ProductEditPage : ContentPage
{
    readonly int _id;
    readonly Entry _name = Ui.Entry("اسم المنتج");
    readonly Entry _nameEn = Ui.Entry("اسم المنتج بالإنجليزية - اختياري");
    readonly Entry _barcode = Ui.Entry("الباركود");
    readonly Entry _sku = Ui.Entry("الكود الداخلي SKU");
    readonly Entry _purchase = Ui.Entry("التكلفة بالدينار");
    readonly Entry _usd = Ui.Entry("التكلفة بالدولار");
    readonly Entry _sale = Ui.Entry("سعر البيع بالتجزئة");
    readonly Entry _wholesale = Ui.Entry("سعر الجملة - اختياري");
    readonly Entry _qty = Ui.Entry("المخزون الافتتاحي");
    readonly Entry _minQty = Ui.Entry("حد التنبيه الأدنى");
    readonly Entry _unit = Ui.Entry("الوحدة: قطعة / كرتونة / كيلو");
    readonly Entry _category = Ui.Entry("التصنيف");
    readonly Entry _supplier = Ui.Entry("المورد - اختياري");
    readonly Entry _part = Ui.Entry("رقم القطعة - اختياري");
    readonly Entry _vehicle = Ui.Entry("توافق السيارة - اختياري");
    readonly Editor _notes = new() { Placeholder = "ملاحظات المنتج", AutoSize = EditorAutoSizeOption.TextChanges, MinimumHeightRequest = 100, BackgroundColor = Ui.CardSurface, TextColor = Ui.Text };
    readonly Switch _active = new() { IsToggled = true, OnColor = Ui.Green };

    public ProductEditPage(int id = 0)
    {
        _id = id;
        Title = id == 0 ? "إضافة منتج" : "تعديل منتج";
        BackgroundColor = Ui.Surface;
        FlowDirection = FlowDirection.RightToLeft;
        Build();
    }

    void Build()
    {
        var header = new Grid { ColumnDefinitions = { new ColumnDefinition(GridLength.Star), new ColumnDefinition(GridLength.Auto) } };
        header.Add(new VerticalStackLayout
        {
            Spacing = 3,
            Children = { Ui.Title(Title), Ui.Subtitle("أدخل بيانات المنتج بدقة ليظهر بشكل صحيح في نقطة البيع والتقارير") }
        }, 0, 0);
        header.Add(new Border
        {
            WidthRequest = 52, HeightRequest = 52, BackgroundColor = Color.FromArgb("#E9F8F2"), StrokeThickness = 0,
            StrokeShape = new Microsoft.Maui.Controls.Shapes.RoundRectangle { CornerRadius = 16 },
            Content = new Label { Text = "▣", FontSize = 26, TextColor = Ui.Green, HorizontalTextAlignment = TextAlignment.Center, VerticalTextAlignment = TextAlignment.Center }
        }, 1, 0);

        var identity = Section("بيانات المنتج", "الاسم والباركود والتصنيف", new View[] { _name, _nameEn, _barcode, _sku, _category, _supplier });
        var pricing = Section("التكلفة والأسعار", "يمكن إدخال التكلفة بالدينار أو الدولار", new View[] { Two(_purchase, _usd), Two(_sale, _wholesale) });
        var inventory = Section("المخزون والوحدة", "حدد الرصيد الافتتاحي وحد التنبيه", new View[] { Two(_qty, _minQty), _unit });
        var extras = Section("تفاصيل إضافية", "مناسبة لقطع السيارات والمنتجات المتخصصة", new View[] { _part, _vehicle, _notes, ToggleRow("المنتج نشط ومتاح للبيع", _active) });

        var camera = Ui.Primary("قراءة الباركود بالكاميرا");
        camera.BackgroundColor = Color.FromArgb("#EAF3FF"); camera.TextColor = Ui.Navy;
        camera.Clicked += async (_, _) =>
        {
            var scanner = new BarcodeScannerPage();
            scanner.BarcodeFound += (_, value) => _barcode.Text = value;
            await Navigation.PushAsync(scanner);
        };

        var save = Ui.Success(_id == 0 ? "حفظ وإضافة المنتج" : "حفظ التعديلات");
        save.Clicked += async (_, _) => await SaveAsync();
        var cancel = Ui.Primary("إلغاء والرجوع"); cancel.BackgroundColor = Colors.Transparent; cancel.TextColor = Ui.Navy; cancel.BorderColor = Ui.Border; cancel.BorderWidth = 1;
        cancel.Clicked += async (_, _) => await Navigation.PopAsync();

        Content = new ScrollView
        {
            Content = new VerticalStackLayout
            {
                Padding = new Thickness(16, 14, 16, 30), Spacing = 14, MaximumWidthRequest = 760, HorizontalOptions = LayoutOptions.Center,
                Children = { header, camera, identity, pricing, inventory, extras, save, cancel }
            }
        };
    }

    Border Section(string title, string subtitle, IEnumerable<View> views)
    {
        var stack = new VerticalStackLayout { Spacing = 10 };
        stack.Add(new Label { Text = title, FontSize = 19, FontAttributes = FontAttributes.Bold, TextColor = Ui.Text });
        stack.Add(new Label { Text = subtitle, FontSize = 12, TextColor = Ui.Muted });
        stack.Add(new BoxView { HeightRequest = 1, Color = Ui.Border });
        foreach (var view in views) stack.Add(view);
        return Ui.Card(stack, new Thickness(16), 20);
    }

    static Grid Two(View first, View second)
    {
        var grid = new Grid { ColumnDefinitions = { new ColumnDefinition(GridLength.Star), new ColumnDefinition(GridLength.Star) }, ColumnSpacing = 10 };
        grid.Add(first, 0, 0); grid.Add(second, 1, 0); return grid;
    }

    static Grid ToggleRow(string text, Switch toggle)
    {
        var grid = new Grid { ColumnDefinitions = { new ColumnDefinition(GridLength.Star), new ColumnDefinition(GridLength.Auto) }, Padding = new Thickness(4, 8) };
        grid.Add(new Label { Text = text, FontSize = 14, TextColor = Ui.Text, VerticalTextAlignment = TextAlignment.Center }, 0, 0);
        grid.Add(toggle, 1, 0); return grid;
    }

    protected override async void OnAppearing()
    {
        base.OnAppearing();
        if (_id == 0) return;
        var p = await AppServices.Database.Db.FindAsync<Product>(_id);
        if (p is null) return;
        _name.Text = p.Name; _barcode.Text = p.Barcode; _purchase.Text = p.PurchasePriceLyd.ToString(); _usd.Text = p.PurchasePriceUsd.ToString();
        _sale.Text = p.SalePrice.ToString(); _qty.Text = p.Quantity.ToString(); _unit.Text = p.Unit; _part.Text = p.PartNumber; _vehicle.Text = p.VehicleCompatibility; _active.IsToggled = p.IsActive;
    }

    async Task SaveAsync()
    {
        if (string.IsNullOrWhiteSpace(_name.Text)) { await Ui.Alert(this, "بيانات ناقصة", "اسم المنتج مطلوب."); return; }
        decimal P(string? value) => decimal.TryParse(value, out var result) ? result : 0;
        var product = _id == 0 ? new Product() : await AppServices.Database.Db.FindAsync<Product>(_id) ?? new Product();
        product.Name = _name.Text.Trim(); product.Barcode = _barcode.Text?.Trim() ?? ""; product.PurchasePriceLyd = P(_purchase.Text); product.PurchasePriceUsd = P(_usd.Text);
        product.SalePrice = P(_sale.Text); product.Quantity = P(_qty.Text); product.Unit = string.IsNullOrWhiteSpace(_unit.Text) ? "قطعة" : _unit.Text.Trim();
        product.PartNumber = _part.Text?.Trim() ?? ""; product.VehicleCompatibility = _vehicle.Text?.Trim() ?? ""; product.IsActive = _active.IsToggled;
        if (product.Id == 0) await AppServices.Database.Db.InsertAsync(product); else await AppServices.Database.Db.UpdateAsync(product);
        await AppServices.Auth.LogAsync("حفظ منتج", product.Name);
        await Ui.Alert(this, "تم الحفظ", "تم حفظ بيانات المنتج بنجاح.");
        await Navigation.PopAsync();
    }
}
