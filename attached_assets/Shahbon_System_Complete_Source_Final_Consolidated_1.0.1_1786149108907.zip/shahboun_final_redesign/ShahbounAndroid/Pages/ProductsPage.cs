using System.Collections.ObjectModel;
using ShahbounAndroid.Models;
using ShahbounAndroid.UI;

namespace ShahbounAndroid.Pages;

public sealed class ProductsPage : ContentPage
{
    private readonly ObservableCollection<Product> _items = new();
    private readonly CollectionView _list;

    public ProductsPage()
    {
        Title = "المنتجات";
        BackgroundColor = Ui.Surface;
        var search = Ui.Entry("بحث بالاسم أو الباركود");
        search.TextChanged += async (_, _) => await LoadAsync(search.Text);

        var scan = Ui.Primary("قراءة باركود بالكاميرا");
        scan.Clicked += async (_, _) =>
        {
            var page = new BarcodeScannerPage();
            page.BarcodeFound += (_, value) => search.Text = value;
            await Navigation.PushAsync(page);
        };

        var add = Ui.Primary("إضافة منتج");
        add.BackgroundColor = Ui.Green;
        add.Clicked += async (_, _) =>
        {
            await Navigation.PushAsync(new ProductEditPage());
        };

        _list = new CollectionView
        {
            ItemsSource = _items,
            SelectionMode = SelectionMode.Single,
            ItemTemplate = new DataTemplate(() =>
            {
                var name = new Label { FontAttributes = FontAttributes.Bold, FontSize = 17, TextColor = Ui.Navy };
                name.SetBinding(Label.TextProperty, nameof(Product.Name));
                var info = new Label { TextColor = Colors.DimGray };
                info.SetBinding(Label.TextProperty, new Binding(path: ".", converter: new ProductInfoConverter()));
                return Ui.Card(new VerticalStackLayout { Spacing = 4, Children = { name, info } });
            })
        };
        _list.SelectionChanged += async (_, e) =>
        {
            if (e.CurrentSelection.FirstOrDefault() is Product p)
            {
                _list.SelectedItem = null;
                await Navigation.PushAsync(new ProductEditPage(p.Id));
            }
        };

        Content = new Grid
        {
            Padding = 14,
            RowDefinitions =
            {
                new RowDefinition(GridLength.Auto),
                new RowDefinition(GridLength.Auto),
                new RowDefinition(GridLength.Auto),
                new RowDefinition(GridLength.Star)
            },
            RowSpacing = 12,
            Children = { search, scan, add, _list }
        };
        Grid.SetRow(scan, 1);
        Grid.SetRow(add, 2);
        Grid.SetRow(_list, 3);
    }

    protected override async void OnAppearing()
    {
        base.OnAppearing();
        await LoadAsync("");
    }

    private async Task LoadAsync(string? query)
    {
        var all = await AppServices.Database.Db.Table<Product>().OrderBy(x => x.Name).ToListAsync();
        if (!string.IsNullOrWhiteSpace(query))
            all = all.Where(x => x.Name.Contains(query, StringComparison.OrdinalIgnoreCase) ||
                                 x.Barcode.Contains(query, StringComparison.OrdinalIgnoreCase)).ToList();
        _items.Clear();
        foreach (var p in all) _items.Add(p);
    }

    private sealed class ProductInfoConverter : IValueConverter
    {
        public object Convert(object? value, Type targetType, object? parameter, System.Globalization.CultureInfo culture) =>
            value is Product p ? $"باركود: {p.Barcode}   |   الكمية: {p.Quantity:0.##}   |   البيع: {p.SalePrice:0.000}" : "";
        public object ConvertBack(object? value, Type targetType, object? parameter, System.Globalization.CultureInfo culture) => throw new NotSupportedException();
    }
}
