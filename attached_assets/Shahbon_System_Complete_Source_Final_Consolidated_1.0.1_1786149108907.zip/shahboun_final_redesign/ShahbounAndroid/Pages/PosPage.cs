using System.Collections.ObjectModel;
using ShahbounAndroid.Models;
using ShahbounAndroid.UI;

namespace ShahbounAndroid.Pages;

public sealed class PosPage : ContentPage
{
    readonly ObservableCollection<CartLine> _cart=new(); readonly Label _total=new(){FontSize=28,FontAttributes=FontAttributes.Bold,TextColor=Ui.Red,HorizontalTextAlignment=TextAlignment.Center}; readonly Entry _scan=Ui.Entry("امسح الباركود أو اكتب اسم المنتج"); readonly VerticalStackLayout _suggestions=new(){Spacing=6};
    public PosPage()
    {
        Title="نقطة البيع";BackgroundColor=Ui.Surface;_scan.TextChanged+=async(_,_)=>await SearchAsync(_scan.Text);_scan.Completed+=async(_,_)=>await AddFirstMatchAsync();
        var cartList=new CollectionView{ItemsSource=_cart,ItemTemplate=new DataTemplate(()=>{var name=new Label{FontAttributes=FontAttributes.Bold,TextColor=Ui.Navy};name.SetBinding(Label.TextProperty,nameof(CartLine.Name));var info=new Label();info.SetBinding(Label.TextProperty,nameof(CartLine.Display));var remove=new Button{Text="حذف",BackgroundColor=Ui.Red,TextColor=Colors.White,FontSize=12};remove.Clicked+=(s,e)=>{if(((Button)s).BindingContext is CartLine line){_cart.Remove(line);UpdateTotal();}};remove.SetBinding(BindingContextProperty,".");return Ui.Card(new Grid{ColumnDefinitions={new ColumnDefinition(GridLength.Star),new ColumnDefinition(GridLength.Auto)},Children={name,info,remove}});})};
        var clear=new Button{Text="مسح السلة",BackgroundColor=Ui.Red,TextColor=Colors.White};clear.Clicked+=(_,_)=>{_cart.Clear();UpdateTotal();};var pay=Ui.Primary("إتمام البيع");pay.BackgroundColor=Ui.Green;pay.Clicked+=async(_,_)=>await CompleteSaleAsync();
        var cameraScan=Ui.Primary("قراءة الباركود بالكاميرا");cameraScan.Clicked+=async(_,_)=>{var page=new BarcodeScannerPage();page.BarcodeFound+=(_,value)=>_scan.Text=value;await Navigation.PushAsync(page);};
        var searchPanel=new VerticalStackLayout{Spacing=8,Children={_scan,cameraScan,_suggestions}};var cartPanel=new VerticalStackLayout{Spacing=10,Children={new Label{Text="سلة الفاتورة",FontSize=22,FontAttributes=FontAttributes.Bold,TextColor=Ui.Navy},cartList,_total,pay,clear}};
        var adaptive=new Grid{Padding=12,ColumnSpacing=14,RowSpacing=14};if(DeviceDisplay.Current.MainDisplayInfo.Width/DeviceDisplay.Current.MainDisplayInfo.Density>=700){adaptive.ColumnDefinitions.Add(new ColumnDefinition(GridLength.Star));adaptive.ColumnDefinitions.Add(new ColumnDefinition(GridLength.Star));adaptive.Add(searchPanel,0,0);adaptive.Add(cartPanel,1,0);}else{adaptive.RowDefinitions.Add(new RowDefinition(GridLength.Auto));adaptive.RowDefinitions.Add(new RowDefinition(GridLength.Star));adaptive.Add(searchPanel,0,0);adaptive.Add(cartPanel,0,1);}Content=adaptive;UpdateTotal();
    }
    async Task SearchAsync(string? q){_suggestions.Clear();if(string.IsNullOrWhiteSpace(q))return;var all=await AppServices.Database.Db.Table<Product>().Where(x=>x.IsActive).Take(100).ToListAsync();foreach(var p in all.Where(x=>x.Barcode==q||x.Name.Contains(q,StringComparison.OrdinalIgnoreCase)).Take(8)){var b=new Button{Text=$"{p.Name} — {p.SalePrice:0.000} — مخزون {p.Quantity:0.###}",BackgroundColor=Colors.White,TextColor=Ui.Navy};b.Clicked+=(_,_)=>AddProduct(p);_suggestions.Add(b);}}
    async Task AddFirstMatchAsync(){var q=_scan.Text?.Trim()??"";var all=await AppServices.Database.Db.Table<Product>().Where(x=>x.IsActive).ToListAsync();var p=all.FirstOrDefault(x=>x.Barcode==q)??all.FirstOrDefault(x=>x.Name.Contains(q,StringComparison.OrdinalIgnoreCase));if(p is not null)AddProduct(p);}
    void AddProduct(Product p){if(p.Quantity<=0){_ = Ui.Alert(this,"نفد المخزون","هذا المنتج غير متوفر.");return;}var line=_cart.FirstOrDefault(x=>x.ProductId==p.Id);if(line is null)_cart.Add(new CartLine{ProductId=p.Id,Name=p.Name,Quantity=1,UnitPrice=p.SalePrice,CostPrice=p.PurchasePriceLyd});else{line.Quantity++;line.Refresh();}_scan.Text="";_suggestions.Clear();UpdateTotal();}
    void UpdateTotal()=>_total.Text=$"الإجمالي: {_cart.Sum(x=>x.Total):0.000} د.ل";
    async Task CompleteSaleAsync()
    {
        if(_cart.Count==0){await Ui.Alert(this,"تنبيه","السلة فارغة.");return;}var method=await DisplayActionSheetAsync("طريقة الدفع","إلغاء",null,"نقدي","حوالة","بطاقة","آجل","دفع مختلط");if(method is null or "إلغاء")return;
        Customer? customer=null;if(method=="آجل"){var customers=await AppServices.Database.Db.Table<Customer>().OrderBy(x=>x.Name).ToListAsync();if(customers.Count==0){await Ui.Alert(this,"لا يوجد عميل","أضف العميل أولاً.");return;}var sel=await DisplayActionSheetAsync("اختر العميل","إلغاء",null,customers.Select(x=>$"{x.Id}|{x.Name}").ToArray());if(sel is null or "إلغاء")return;customer=customers.First(x=>x.Id==int.Parse(sel.Split('|')[0]));}
        var subtotal=_cart.Sum(x=>x.Total);var discount=await PromptUtil.DecimalAsync(this,"الخصم","قيمة الخصم","0")??0;if(discount<0||discount>subtotal)discount=0;var total=subtotal-discount;var paid=method=="آجل"?0:(await PromptUtil.DecimalAsync(this,"المدفوع","المبلغ المدفوع",total.ToString())??total);if(paid>total)paid=total;
        var sale=new Sale{InvoiceNumber=$"S-{DateTime.Now:yyyyMMdd-HHmmss}",CreatedAt=DateTime.Now,UserId=AppServices.Auth.CurrentUser?.Id??0,CustomerId=customer?.Id,Subtotal=subtotal,Discount=discount,Total=total,Paid=paid,PaymentMethod=method};
        await AppServices.Database.Db.RunInTransactionAsync(conn=>{conn.Insert(sale);foreach(var c in _cart){conn.Insert(new SaleItem{SaleId=sale.Id,ProductId=c.ProductId,ProductName=c.Name,Quantity=c.Quantity,UnitPrice=c.UnitPrice,CostPrice=c.CostPrice,Total=c.Total});var p=conn.Find<Product>(c.ProductId);if(p is not null){p.Quantity-=c.Quantity;conn.Update(p);conn.Insert(new StockMovement{ProductId=p.Id,ProductName=p.Name,QuantityChange=-c.Quantity,MovementType="بيع",Reference=sale.InvoiceNumber,CreatedAt=DateTime.Now});}}if(customer is not null){customer.Balance+=total-paid;conn.Update(customer);}if(paid>0)conn.Insert(new CashTransaction{Type="إيداع",Amount=paid,Method=method,Description=$"بيع {sale.InvoiceNumber}",CreatedAt=DateTime.Now,UserId=sale.UserId});});
        await AppServices.Auth.LogAsync("بيع",$"الفاتورة {sale.InvoiceNumber} بقيمة {sale.Total:0.000}");
        if(method=="حوالة") await AppServices.Database.Db.InsertAsync(new TransferPayment{CreatedAtUtc=DateTime.UtcNow,SaleId=sale.Id,Amount=paid,Status="قيد المراجعة"});
        _cart.Clear();UpdateTotal();
        var open=await DisplayAlert("تم البيع",$"تم حفظ الفاتورة {sale.InvoiceNumber}\nالإجمالي {sale.Total:0.000} د.ل\nالمدفوع {sale.Paid:0.000} د.ل", "فتح الفاتورة", "إغلاق");
        if(open) await Navigation.PushAsync(new InvoiceViewerPage(sale.Id));
    }
    sealed class CartLine:BindableObject{public int ProductId{get;set;}public string Name{get;set;}="";decimal _quantity;public decimal Quantity{get=>_quantity;set{_quantity=value;OnPropertyChanged();OnPropertyChanged(nameof(Display));}}public decimal UnitPrice{get;set;}public decimal CostPrice{get;set;}public decimal Total=>Quantity*UnitPrice;public string Display=>$"{Quantity:0.##} × {UnitPrice:0.000} = {Total:0.000}";public void Refresh(){OnPropertyChanged(nameof(Quantity));OnPropertyChanged(nameof(Display));}}
}
