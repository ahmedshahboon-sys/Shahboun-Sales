using ShahbounAndroid.UI;
using ZXing.Net.Maui;
using ZXing.Net.Maui.Controls;

namespace ShahbounAndroid.Pages;

public sealed class BarcodeScannerPage : ContentPage
{
    readonly CameraBarcodeReaderView _camera = new() { HorizontalOptions = LayoutOptions.Fill, VerticalOptions = LayoutOptions.Fill };
    readonly Label _result = new() { Text = "وجّه الكاميرا إلى الباركود", HorizontalTextAlignment = TextAlignment.Center, FontSize = 18 };
    bool _handled;
    public event EventHandler<string>? BarcodeFound;

    public BarcodeScannerPage()
    {
        Title = "قراءة الباركود";
        _camera.Options = new BarcodeReaderOptions { Formats = BarcodeFormats.OneDimensional, AutoRotate = true, Multiple = false };
        _camera.BarcodesDetected += OnDetected;
        var flash = Ui.Primary("تشغيل / إيقاف الفلاش");
        flash.Clicked += (_, _) => _camera.IsTorchOn = !_camera.IsTorchOn;
        Content = new Grid
        {
            RowDefinitions = { new RowDefinition(GridLength.Star), new RowDefinition(GridLength.Auto) },
            Children =
            {
                _camera,
                new VerticalStackLayout { Padding = 14, Spacing = 8, BackgroundColor = Colors.White, Children = { _result, flash } }
            }
        };
        Grid.SetRow((View)((Grid)Content).Children[1], 1);
    }

    void OnDetected(object? sender, BarcodeDetectionEventArgs e)
    {
        if (_handled) return;
        var value = e.Results.FirstOrDefault()?.Value;
        if (string.IsNullOrWhiteSpace(value)) return;
        _handled = true;
        MainThread.BeginInvokeOnMainThread(async () =>
        {
            _result.Text = value;
            BarcodeFound?.Invoke(this, value);
            await Clipboard.Default.SetTextAsync(value);
            await DisplayAlert("تمت القراءة", $"الباركود: {value}\nتم نسخه.", "حسنًا");
            await Navigation.PopAsync();
        });
    }
}
