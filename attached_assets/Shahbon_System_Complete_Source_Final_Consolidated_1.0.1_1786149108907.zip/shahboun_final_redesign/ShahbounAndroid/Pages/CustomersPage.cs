using ShahbounAndroid.Models;
using ShahbounAndroid.UI;

namespace ShahbounAndroid.Pages;

public sealed class CustomersPage : ContentPage
{
    readonly VerticalStackLayout _list = new() { Spacing = 8 };
    public CustomersPage()
    {
        Title="العملاء والديون";BackgroundColor=Ui.Surface;var add=Ui.Primary("إضافة عميل");add.BackgroundColor=Ui.Green;add.Clicked+=async(_,_)=>await AddAsync();Content=new ScrollView{Content=new VerticalStackLayout{Padding=14,Spacing=12,Children={add,_list}}};
    }
    protected override async void OnAppearing(){base.OnAppearing();await LoadAsync();}
    async Task LoadAsync()
    {
        _list.Clear();foreach(var c in await AppServices.Database.Db.Table<Customer>().OrderBy(x=>x.Name).ToListAsync())
        {
            var b=new Button{Text=$"{c.Name}\n{c.Phone} — الرصيد: {c.Balance:0.000}",BackgroundColor=Colors.White,TextColor=Ui.Navy};
            b.Clicked+=async(_,_)=>{var action=await DisplayActionSheetAsync(c.Name,"إلغاء",null,"تسجيل دفعة","تعديل الرصيد","تعديل البيانات");if(action=="تسجيل دفعة"){var a=await PromptUtil.DecimalAsync(this,"دفعة عميل","قيمة الدفعة");if(a is null)return;await AppServices.Database.Db.InsertAsync(new CustomerPayment{CustomerId=c.Id,Amount=a.Value,CreatedAt=DateTime.Now});c.Balance-=a.Value;await AppServices.Database.Db.UpdateAsync(c);await AppServices.Database.Db.InsertAsync(new CashTransaction{Type="إيداع",Amount=a.Value,Description=$"دفعة عميل: {c.Name}",CreatedAt=DateTime.Now,UserId=AppServices.Auth.CurrentUser?.Id??0});}else if(action=="تعديل الرصيد"){var a=await PromptUtil.DecimalAsync(this,"الرصيد","الرصيد الجديد",c.Balance.ToString());if(a is null)return;c.Balance=a.Value;await AppServices.Database.Db.UpdateAsync(c);}else if(action=="تعديل البيانات"){var phone=await DisplayPromptAsync("تعديل العميل","رقم الهاتف",initialValue:c.Phone);var address=await DisplayPromptAsync("تعديل العميل","العنوان",initialValue:c.Address);c.Phone=phone??c.Phone;c.Address=address??c.Address;await AppServices.Database.Db.UpdateAsync(c);}await LoadAsync();};
            _list.Add(b);
        }
    }
    async Task AddAsync(){var name=await DisplayPromptAsync("عميل جديد","اسم العميل");if(string.IsNullOrWhiteSpace(name))return;var phone=await DisplayPromptAsync("عميل جديد","رقم الهاتف");var address=await DisplayPromptAsync("عميل جديد","العنوان");await AppServices.Database.Db.InsertAsync(new Customer{Name=name.Trim(),Phone=phone?.Trim()??"",Address=address?.Trim()??""});await LoadAsync();}
}
