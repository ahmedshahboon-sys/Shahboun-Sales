using ShahbounAndroid.Models;
using ShahbounAndroid.UI;

namespace ShahbounAndroid.Pages;

public sealed class BusinessRegistrationPage : ContentPage
{
    private readonly Entry _store = Ui.Entry("اسم المتجر أو النشاط");
    private readonly Entry _owner = Ui.Entry("اسم صاحب النشاط");
    private readonly Entry _phone = Ui.Entry("رقم الهاتف");
    private readonly Entry _whatsapp = Ui.Entry("رقم واتساب");
    private readonly Entry _city = Ui.Entry("المدينة - اختياري");
    private readonly Entry _email = Ui.Entry("البريد الإلكتروني - اختياري");
    private readonly Picker _activity = new() { Title = "نوع النشاط" };
    private readonly CheckBox _consent = new();

    public BusinessRegistrationPage()
    {
        Title = "بيانات النشاط";
        BackgroundColor = Ui.Surface;
        NavigationPage.SetHasNavigationBar(this, false);
        foreach (var item in new[] { "بقالة", "ملابس", "صيدلية", "قطع غيار", "إلكترونيات", "تجارة إلكترونية", "جملة", "خدمات وصيانة", "مواد بناء", "مطعم أو مقهى", "عام" })
            _activity.Items.Add(item);

        var save = Ui.Primary("حفظ ومتابعة");
        save.Clicked += async (_, _) => await SaveAsync();

        Content = new ScrollView
        {
            Content = new VerticalStackLayout
            {
                Padding = new Thickness(24, 36),
                Spacing = 14,
                MaximumWidthRequest = 680,
                HorizontalOptions = LayoutOptions.Center,
                Children =
                {
                    new Image { Source = "shahboun_logo.png", HeightRequest = 110, Aspect = Aspect.AspectFit },
                    Ui.Title("بيانات النشاط قبل التفعيل"),
                    new Label { Text = "هذه البيانات تُستخدم للتفعيل والدعم وتظهر في الفواتير.", HorizontalTextAlignment = TextAlignment.Center, TextColor = Colors.DimGray },
                    _store, _owner, _phone, _whatsapp, _city, _activity, _email,
                    new HorizontalStackLayout
                    {
                        Spacing = 8,
                        Children = { _consent, new Label { Text = "أوافق على حفظ بيانات التواصل لغرض الدعم والتفعيل", VerticalTextAlignment = TextAlignment.Center } }
                    },
                    save
                }
            }
        };
    }

    private async Task SaveAsync()
    {
        if (string.IsNullOrWhiteSpace(_store.Text) || string.IsNullOrWhiteSpace(_owner.Text) || string.IsNullOrWhiteSpace(_phone.Text))
        {
            await DisplayAlert("بيانات ناقصة", "اسم المتجر واسم صاحب النشاط ورقم الهاتف مطلوبة.", "حسنًا");
            return;
        }
        if (!_consent.IsChecked)
        {
            await DisplayAlert("الموافقة مطلوبة", "لازم توافق على حفظ بيانات التواصل لغرض الدعم والتفعيل.", "حسنًا");
            return;
        }
        var profile = new BusinessProfile
        {
            Id = 1, StoreName = _store.Text!.Trim(), OwnerName = _owner.Text!.Trim(), Phone = _phone.Text!.Trim(),
            WhatsApp = string.IsNullOrWhiteSpace(_whatsapp.Text) ? _phone.Text!.Trim() : _whatsapp.Text!.Trim(),
            City = _city.Text?.Trim() ?? "", ActivityType = _activity.SelectedItem?.ToString() ?? "عام",
            Email = _email.Text?.Trim() ?? "", SupportContactConsent = true, CreatedAtUtc = DateTime.UtcNow
        };
        await AppServices.Database.Db.InsertOrReplaceAsync(profile);
        Application.Current!.Windows[0].Page = new NavigationPage(new ActivationPage());
    }
}
