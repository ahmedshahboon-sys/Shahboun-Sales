using ShahbounAndroid.UI;

namespace ShahbounAndroid.Pages;

public sealed class InvoiceViewerPage : ContentPage
{
    readonly int _saleId;
    string _path = "";
    readonly WebView _web = new();
    public InvoiceViewerPage(int saleId) { _saleId = saleId; Title = "الفاتورة"; }
    protected override async void OnAppearing()
    {
        base.OnAppearing();
        if (!string.IsNullOrWhiteSpace(_path)) return;
        _path = await AppServices.Invoices.CreateHtmlAsync(_saleId);
        _web.Source = new UrlWebViewSource { Url = _path };
        var share = Ui.Success("مشاركة الفاتورة"); share.Clicked += async (_, _) => await Share.Default.RequestAsync(new ShareFileRequest { Title = "فاتورة منظومة شهبون", File = new ShareFile(_path) });
        var print = Ui.Primary("فتح للطباعة / PDF"); print.Clicked += async (_, _) => await Launcher.Default.OpenAsync(new OpenFileRequest("فاتورة", new ReadOnlyFile(_path)));
        Content = new Grid { RowDefinitions = { new RowDefinition(GridLength.Star), new RowDefinition(GridLength.Auto) }, Children = { _web, new HorizontalStackLayout { Padding = 10, Spacing = 10, HorizontalOptions = LayoutOptions.Center, Children = { share, print } } } };
        Grid.SetRow(((Grid)Content).Children[1], 1);
    }
}
