using ShahbounAndroid.Models;
using ShahbounAndroid.UI;

namespace ShahbounAndroid.Pages;

public sealed class UsersPage : ContentPage
{
    private readonly VerticalStackLayout _list = new() { Spacing = 8 };
    public UsersPage()
    {
        Title = "المستخدمون والصلاحيات";
        BackgroundColor = Ui.Surface;
        var add = Ui.Primary("إضافة مستخدم");
        add.BackgroundColor = Ui.Green;
        add.Clicked += async (_, _) => await AddAsync();
        Content = new ScrollView { Content = new VerticalStackLayout { Padding = 14, Spacing = 12, Children = { add, _list } } };
    }
    protected override async void OnAppearing() { base.OnAppearing(); await LoadAsync(); }
    private async Task LoadAsync()
    {
        _list.Clear();
        var users = await AppServices.Database.Db.Table<UserAccount>().OrderBy(x => x.Username).ToListAsync();
        foreach (var u in users)
        {
            var b = new Button
            {
                Text = $"{u.Username} — {(u.IsAdmin ? "مدير" : "مستخدم")}\n{u.PermissionsCsv}",
                BackgroundColor = Colors.White,
                TextColor = Ui.Navy,
                HorizontalOptions = LayoutOptions.Fill
            };
            b.Clicked += async (_, _) =>
            {
                if (u.Username == "admin") return;
                var ok = await DisplayAlertAsync("تغيير الحالة", $"هل تريد {(u.IsActive ? "إيقاف" : "تفعيل")} المستخدم {u.Username}؟", "نعم", "لا");
                if (!ok) return;
                u.IsActive = !u.IsActive;
                await AppServices.Database.Db.UpdateAsync(u);
                await LoadAsync();
            };
            _list.Add(b);
        }
    }
    private async Task AddAsync()
    {
        var username = await DisplayPromptAsync("مستخدم جديد", "اسم المستخدم");
        if (string.IsNullOrWhiteSpace(username)) return;
        var password = await DisplayPromptAsync("مستخدم جديد", "كلمة المرور", keyboard: Keyboard.Text);
        if ((password?.Length ?? 0) < 6) { await Ui.Alert(this, "تنبيه", "كلمة المرور 6 خانات على الأقل."); return; }
        var role = await DisplayActionSheetAsync("نوع الصلاحيات", "إلغاء", null, "كاشير: بيع فقط", "مخزون ومنتجات", "مشتريات وموردون", "خزينة ومصروفات", "متجر إلكتروني", "تقارير فقط", "كل الصلاحيات");
        if (role == "إلغاء" || role is null) return;
        var permissions = role switch
        {
            "كاشير: بيع فقط" => "sales,customers",
            "مخزون ومنتجات" => "products",
            "مشتريات وموردون" => "purchases,suppliers,products",
            "خزينة ومصروفات" => "cash,expenses",
            "متجر إلكتروني" => "orders,customers",
            "تقارير فقط" => "reports",
            _ => "*"
        };
        var (hash, salt) = Services.PasswordHasher.Hash(password!);
        try
        {
            await AppServices.Database.Db.InsertAsync(new UserAccount
            {
                Username = username.Trim().ToLowerInvariant(),
                PasswordHash = hash,
                PasswordSalt = salt,
                IsAdmin = permissions == "*",
                PermissionsCsv = permissions
            });
            await LoadAsync();
        }
        catch { await Ui.Alert(this, "تعذر الحفظ", "اسم المستخدم موجود مسبقاً."); }
    }
}
