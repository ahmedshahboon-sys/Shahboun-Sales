using ShahbounAndroid.Models;
using ShahbounAndroid.UI;

namespace ShahbounAndroid.Pages;

public sealed class DashboardPage : ContentPage
{
    readonly Label _salesValue = StatValue("0.000 د.ل", Ui.Green);
    readonly Label _invoiceValue = StatValue("0", Ui.Navy);
    readonly Label _productsValue = StatValue("0", Ui.Green);
    readonly Label _expenseValue = StatValue("0.000 د.ل", Ui.Red);
    readonly Label _clock = new() { FontSize = 12, TextColor = Ui.Muted };
    IDispatcherTimer? _timer;

    public DashboardPage()
    {
        Title = "الرئيسية";
        FlowDirection = FlowDirection.RightToLeft;
        Build();
    }

    static Label StatValue(string text, Color color) => new()
    {
        Text = text,
        FontSize = 18,
        FontAttributes = FontAttributes.Bold,
        TextColor = color,
        HorizontalTextAlignment = TextAlignment.Center
    };

    void Build()
    {
        var top = new Grid
        {
            ColumnDefinitions = { new ColumnDefinition(GridLength.Star), new ColumnDefinition(GridLength.Auto) },
            Margin = new Thickness(0, 4, 0, 0)
        };
        var title = Ui.Title("الرئيسية");
        var notification = new Border
        {
            WidthRequest = 48,
            HeightRequest = 48,
            BackgroundColor = Ui.CardSurface,
            Stroke = Ui.Border,
            StrokeShape = new Microsoft.Maui.Controls.Shapes.RoundRectangle { CornerRadius = 15 },
            Content = new Label { Text = "🔔", FontSize = 22, HorizontalTextAlignment = TextAlignment.Center, VerticalTextAlignment = TextAlignment.Center }
        };
        top.Add(title, 0, 0);
        top.Add(notification, 1, 0);

        var welcomeText = new VerticalStackLayout
        {
            Spacing = 4,
            VerticalOptions = LayoutOptions.Center,
            Children =
            {
                new Label { Text = "مرحباً بك", FontSize = 14, TextColor = Colors.White.WithAlpha(.82f) },
                new Label { Text = "مؤسسة شهبون التجارية", FontSize = 22, FontAttributes = FontAttributes.Bold, TextColor = Colors.White },
                new Label { Text = "نظام متكامل لإدارة مبيعاتك بذكاء", FontSize = 13, TextColor = Colors.White.WithAlpha(.78f) }
            }
        };
        var welcome = new Border
        {
            BackgroundColor = Ui.Navy,
            StrokeThickness = 0,
            Padding = new Thickness(20),
            StrokeShape = new Microsoft.Maui.Controls.Shapes.RoundRectangle { CornerRadius = 24 },
            Content = new Grid
            {
                ColumnDefinitions = { new ColumnDefinition(GridLength.Star), new ColumnDefinition(GridLength.Auto) },
                Children =
                {
                    welcomeText,
                    new Image { Source = "shahboun_symbol.png", HeightRequest = 90, WidthRequest = 90, Opacity = .95, HorizontalOptions = LayoutOptions.End }
                }
            }
        };
        Grid.SetColumn(welcome.Content.As<Grid>()!.Children[1], 1);

        var stats = new Grid
        {
            ColumnDefinitions = { new ColumnDefinition(GridLength.Star), new ColumnDefinition(GridLength.Star) },
            RowDefinitions = { new RowDefinition(GridLength.Auto), new RowDefinition(GridLength.Auto) },
            ColumnSpacing = 8,
            RowSpacing = 8
        };
        stats.Add(StatCard("إجمالي المبيعات", _salesValue, "اليوم", "💵"), 0, 0);
        stats.Add(StatCard("عدد الفواتير", _invoiceValue, "اليوم", "🧾"), 1, 0);
        stats.Add(StatCard("عدد المنتجات", _productsValue, "إجمالي", "🛍️"), 0, 1);
        stats.Add(StatCard("إجمالي المصروفات", _expenseValue, "اليوم", "👛"), 1, 1);

        var modules = new Grid
        {
            ColumnDefinitions = { new ColumnDefinition(GridLength.Star), new ColumnDefinition(GridLength.Star), new ColumnDefinition(GridLength.Star) },
            ColumnSpacing = 9,
            RowSpacing = 9
        };

        AddModule(modules, 0, 0, "icon_invoices.svg", "الفواتير", "عرض وإدارة الفواتير", "sales", () => new SalesHistoryPage());
        AddModule(modules, 1, 0, "icon_pos.svg", "نقطة البيع", "بيع سريع وإصدار فاتورة", "sales", () => new PosPage());
        AddModule(modules, 2, 0, "icon_products.svg", "المنتجات", "إدارة المنتجات والأصناف", "products", () => new ProductsPage());
        AddModule(modules, 0, 1, "icon_inventory.svg", "المخزون", "حركة المخزون والجرد", "products", () => new InventoryPage());
        AddModule(modules, 1, 1, "icon_suppliers.svg", "الموردون", "إدارة بيانات الموردين", "suppliers", () => new SuppliersPage());
        AddModule(modules, 2, 1, "icon_customers.svg", "العملاء", "إدارة بيانات العملاء", "customers", () => new CustomersPage());
        AddModule(modules, 0, 2, "icon_settings.svg", "الإعدادات", "تخصيص إعدادات النظام", "settings", () => new SettingsPage());
        AddModule(modules, 1, 2, "icon_reports.svg", "التقارير", "تقارير تفصيلية ذكية", "reports", () => new ReportsPage());
        AddModule(modules, 2, 2, "icon_expenses.svg", "المصروفات", "تسجيل ومتابعة المصروفات", "expenses", () => new ExpensesPage());

        var safe = new Border
        {
            BackgroundColor = Color.FromArgb("#EAF8F2"),
            Stroke = Color.FromArgb("#B7E6D4"),
            StrokeThickness = 1,
            Padding = new Thickness(14, 10),
            StrokeShape = new Microsoft.Maui.Controls.Shapes.RoundRectangle { CornerRadius = 16 },
            Content = new HorizontalStackLayout
            {
                Spacing = 10,
                Children =
                {
                    new Label { Text = "🛡️", FontSize = 28, VerticalTextAlignment = TextAlignment.Center },
                    new VerticalStackLayout
                    {
                        Spacing = 2,
                        Children =
                        {
                            new Label { Text = "بياناتك آمنة معنا", FontSize = 14, FontAttributes = FontAttributes.Bold, TextColor = Ui.Green },
                            new Label { Text = "نسخ احتياطي تلقائي وحماية على أعلى مستوى", FontSize = 11, TextColor = Ui.Green }
                        }
                    }
                }
            }
        };

        var bottom = new Grid
        {
            ColumnDefinitions = { new ColumnDefinition(GridLength.Star), new ColumnDefinition(GridLength.Star), new ColumnDefinition(GridLength.Star), new ColumnDefinition(GridLength.Star), new ColumnDefinition(GridLength.Star) },
            Padding = new Thickness(8, 8, 8, 4),
            BackgroundColor = Ui.CardSurface
        };
        bottom.Add(BottomItem("⌂", "الرئيسية", Ui.Green, null), 0, 0);
        bottom.Add(BottomItem("🔔", "التنبيهات", Ui.Navy, async () => await Ui.Alert(this, "التنبيهات", "مركز التنبيهات قيد المراجعة النهائية.")), 1, 0);
        bottom.Add(BottomItem("＋", "إضافة", Ui.Green, async () => await Navigation.PushAsync(new ProductEditPage())), 2, 0);
        bottom.Add(BottomItem("◔", "التقارير", Ui.Navy, async () => await Navigation.PushAsync(new ReportsPage())), 3, 0);
        bottom.Add(BottomItem("●", "المزيد", Ui.Navy, async () => await Navigation.PushAsync(new SettingsPage())), 4, 0);

        var support = new Grid { ColumnDefinitions = { new ColumnDefinition(GridLength.Star), new ColumnDefinition(GridLength.Auto) } };
        support.Add(new VerticalStackLayout
        {
            Spacing = 1,
            Children =
            {
                new Label { Text = "الدعم الفني", FontSize = 12, FontAttributes = FontAttributes.Bold, TextColor = Ui.Text },
                new Label { Text = "متواجدون لخدمتكم دائماً", FontSize = 10, TextColor = Ui.Muted }
            }
        }, 0, 0);
        support.Add(new Label { Text = "0912992050", FontSize = 13, FontAttributes = FontAttributes.Bold, TextColor = Ui.Navy, VerticalTextAlignment = TextAlignment.Center }, 1, 0);

        var body = new VerticalStackLayout
        {
            Padding = new Thickness(14, 10, 14, 20),
            Spacing = 14,
            Children = { top, welcome, stats, modules, safe, support, bottom }
        };
        Content = new ScrollView { Content = body };
    }

    View StatCard(string title, Label value, string note, string icon) => Ui.Card(new VerticalStackLayout
    {
        Spacing = 4,
        Children =
        {
            new Label { Text = icon, FontSize = 23, HorizontalTextAlignment = TextAlignment.Center },
            new Label { Text = title, FontSize = 11, TextColor = Ui.Muted, HorizontalTextAlignment = TextAlignment.Center },
            value,
            new Label { Text = note, FontSize = 10, TextColor = Ui.Muted, HorizontalTextAlignment = TextAlignment.Center }
        }
    }, new Thickness(10), 17);

    void AddModule(Grid grid, int col, int row, string icon, string title, string subtitle, string permission, Func<Page> page)
    {
        var card = Ui.ModuleCard(icon, title, subtitle, async (_, _) =>
        {
            if (!AppServices.Auth.HasPermission(permission))
            {
                await Ui.Alert(this, "غير مسموح", "ليس لديك صلاحية لفتح هذه الشاشة.");
                return;
            }
            await Navigation.PushAsync(page());
        });
        grid.Add(card, col, row);
    }

    View BottomItem(string icon, string text, Color color, Func<Task>? action)
    {
        var stack = new VerticalStackLayout
        {
            Spacing = 1,
            Children =
            {
                new Label { Text = icon, FontSize = 22, TextColor = color, HorizontalTextAlignment = TextAlignment.Center },
                new Label { Text = text, FontSize = 10, TextColor = color, HorizontalTextAlignment = TextAlignment.Center }
            }
        };
        if (action is not null)
        {
            var tap = new TapGestureRecognizer();
            tap.Tapped += async (_, _) => await action();
            stack.GestureRecognizers.Add(tap);
        }
        return stack;
    }

    protected override async void OnAppearing()
    {
        base.OnAppearing();
        await LoadStatsAsync();
        UpdateClock();
        _timer = Dispatcher.CreateTimer();
        _timer.Interval = TimeSpan.FromSeconds(1);
        _timer.Tick += (_, _) => UpdateClock();
        _timer.Start();
    }

    protected override void OnDisappearing()
    {
        _timer?.Stop();
        base.OnDisappearing();
    }

    async Task LoadStatsAsync()
    {
        var today = DateTime.Today;
        var tomorrow = today.AddDays(1);
        var sales = await AppServices.Database.Db.Table<Sale>().Where(x => x.CreatedAt >= today && x.CreatedAt < tomorrow).ToListAsync();
        var expenses = await AppServices.Database.Db.Table<Expense>().Where(x => x.CreatedAt >= today && x.CreatedAt < tomorrow).ToListAsync();
        var products = await AppServices.Database.Db.Table<Product>().CountAsync();
        _salesValue.Text = $"{sales.Sum(x => x.Total):0.000} د.ل";
        _invoiceValue.Text = sales.Count.ToString();
        _productsValue.Text = products.ToString();
        _expenseValue.Text = $"{expenses.Sum(x => x.Amount):0.000} د.ل";
    }

    void UpdateClock()
    {
        var now = DateTime.Now;
        _clock.Text = now.ToString("HH:mm");
    }
}

static class ViewCastExtensions
{
    public static T? As<T>(this object? value) where T : class => value as T;
}
