using ShahbounAndroid.Models;
using ShahbounAndroid.UI;

namespace ShahbounAndroid.Pages;

public sealed class CashboxPage : ContentPage
{
    readonly VerticalStackLayout _list = new() { Spacing = 8 };
    public CashboxPage()
    {
        Title = "الخزينة"; BackgroundColor = Ui.Surface;
        var deposit = Ui.Primary("إيداع"); deposit.BackgroundColor = Ui.Green; deposit.Clicked += async (_,_) => await AddAsync("إيداع");
        var withdraw = Ui.Primary("سحب"); withdraw.BackgroundColor = Ui.Red; withdraw.Clicked += async (_,_) => await AddAsync("سحب");
        Content = new ScrollView { Content = new VerticalStackLayout { Padding = 14, Spacing = 12, Children = { new HorizontalStackLayout { Spacing = 10, Children = { deposit, withdraw } }, _list } } };
    }
    protected override async void OnAppearing() { base.OnAppearing(); await LoadAsync(); }
    async Task LoadAsync()
    {
        _list.Clear(); var tx = await AppServices.Database.Db.Table<CashTransaction>().OrderByDescending(x => x.Id).Take(100).ToListAsync();
        var balance = tx.Sum(x => x.Type == "إيداع" ? x.Amount : -x.Amount);
        _list.Add(Ui.Card(new Label { Text = $"الرصيد المسجل: {balance:0.000} د.ل", FontSize = 22, FontAttributes = FontAttributes.Bold, TextColor = balance >= 0 ? Ui.Green : Ui.Red }));
        foreach (var x in tx) _list.Add(Ui.Card(new Label { Text = $"{x.CreatedAt:yyyy-MM-dd HH:mm} — {x.Type}\n{x.Description}\n{x.Amount:0.000} د.ل ({x.Method})", TextColor = Ui.Navy }));
    }
    async Task AddAsync(string type)
    {
        var amount = await PromptUtil.DecimalAsync(this, type, "القيمة"); if (amount is null) return;
        var desc = await DisplayPromptAsync(type, "البيان");
        await AppServices.Database.Db.InsertAsync(new CashTransaction { Type = type, Amount = amount.Value, Description = desc?.Trim() ?? "", CreatedAt = DateTime.Now, UserId = AppServices.Auth.CurrentUser?.Id ?? 0 }); await LoadAsync();
    }
}
