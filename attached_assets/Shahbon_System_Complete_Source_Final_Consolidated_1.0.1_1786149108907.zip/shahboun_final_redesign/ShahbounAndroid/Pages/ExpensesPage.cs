using ShahbounAndroid.Models;
using ShahbounAndroid.UI;

namespace ShahbounAndroid.Pages;

public sealed class ExpensesPage : ContentPage
{
    readonly VerticalStackLayout _list = new() { Spacing = 8 };
    public ExpensesPage()
    {
        Title = "المصروفات"; BackgroundColor = Ui.Surface;
        var add = Ui.Primary("إضافة مصروف"); add.BackgroundColor = Ui.Red; add.Clicked += async (_,_) => await AddAsync();
        Content = new ScrollView { Content = new VerticalStackLayout { Padding = 14, Spacing = 12, Children = { add, _list } } };
    }
    protected override async void OnAppearing() { base.OnAppearing(); await LoadAsync(); }
    async Task LoadAsync()
    {
        _list.Clear(); var rows = await AppServices.Database.Db.Table<Expense>().OrderByDescending(x => x.Id).Take(100).ToListAsync();
        var total = rows.Where(x => x.CreatedAt.Date == DateTime.Today).Sum(x => x.Amount);
        _list.Add(Ui.Card(new Label { Text = $"مصروفات اليوم: {total:0.000} د.ل", FontSize = 20, FontAttributes = FontAttributes.Bold, TextColor = Ui.Red }));
        foreach (var x in rows) _list.Add(Ui.Card(new Label { Text = $"{x.CreatedAt:yyyy-MM-dd HH:mm} — {x.Category}\n{x.Description}\n{x.Amount:0.000} د.ل", TextColor = Ui.Navy }));
    }
    async Task AddAsync()
    {
        var category = await DisplayPromptAsync("مصروف جديد", "التصنيف (إيجار، كهرباء، نقل...)"); if (string.IsNullOrWhiteSpace(category)) return;
        var desc = await DisplayPromptAsync("مصروف جديد", "البيان"); var amount = await PromptUtil.DecimalAsync(this, "مصروف جديد", "القيمة"); if (amount is null) return;
        await AppServices.Database.Db.InsertAsync(new Expense { Category = category.Trim(), Description = desc?.Trim() ?? "", Amount = amount.Value, CreatedAt = DateTime.Now });
        await AppServices.Database.Db.InsertAsync(new CashTransaction { Type = "سحب", Amount = amount.Value, Description = $"مصروف: {category}", CreatedAt = DateTime.Now, UserId = AppServices.Auth.CurrentUser?.Id ?? 0 });
        await LoadAsync();
    }
}
