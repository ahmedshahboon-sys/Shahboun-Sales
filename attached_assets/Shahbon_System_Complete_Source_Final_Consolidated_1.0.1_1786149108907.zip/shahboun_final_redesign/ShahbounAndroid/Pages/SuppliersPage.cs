using ShahbounAndroid.Models;
using ShahbounAndroid.UI;

namespace ShahbounAndroid.Pages;

public sealed class SuppliersPage : ContentPage
{
    readonly VerticalStackLayout _list = new() { Spacing = 8 };
    public SuppliersPage()
    {
        Title = "الموردون"; BackgroundColor = Ui.Surface;
        var add = Ui.Primary("إضافة مورد"); add.BackgroundColor = Ui.Green; add.Clicked += async (_,_) => await AddAsync();
        Content = new ScrollView { Content = new VerticalStackLayout { Padding = 14, Spacing = 12, Children = { add, _list } } };
    }
    protected override async void OnAppearing() { base.OnAppearing(); await LoadAsync(); }
    async Task LoadAsync()
    {
        _list.Clear();
        foreach (var s in await AppServices.Database.Db.Table<Supplier>().OrderBy(x => x.Name).ToListAsync())
        {
            var button = new Button { Text = $"{s.Name}\n{s.Phone} — الرصيد: {s.Balance:0.000}", BackgroundColor = Colors.White, TextColor = Ui.Navy };
            button.Clicked += async (_,_) =>
            {
                var action = await DisplayActionSheetAsync(s.Name, "إلغاء", null, "تسجيل دفعة", "تعديل الرصيد");
                if (action == "تسجيل دفعة")
                {
                    var amount = await PromptUtil.DecimalAsync(this, "دفعة مورد", "قيمة الدفعة"); if (amount is null) return;
                    await AppServices.Database.Db.InsertAsync(new SupplierPayment { SupplierId = s.Id, Amount = amount.Value, CreatedAt = DateTime.Now });
                    s.Balance -= amount.Value; await AppServices.Database.Db.UpdateAsync(s);
                }
                else if (action == "تعديل الرصيد")
                {
                    var balance = await PromptUtil.DecimalAsync(this, "الرصيد", "الرصيد الجديد", s.Balance.ToString()); if (balance is null) return;
                    s.Balance = balance.Value; await AppServices.Database.Db.UpdateAsync(s);
                }
                await LoadAsync();
            };
            _list.Add(button);
        }
    }
    async Task AddAsync()
    {
        var name = await DisplayPromptAsync("مورد جديد", "اسم المورد"); if (string.IsNullOrWhiteSpace(name)) return;
        var phone = await DisplayPromptAsync("مورد جديد", "رقم الهاتف");
        var address = await DisplayPromptAsync("مورد جديد", "العنوان");
        await AppServices.Database.Db.InsertAsync(new Supplier { Name = name.Trim(), Phone = phone?.Trim() ?? "", Address = address?.Trim() ?? "" }); await LoadAsync();
    }
}
