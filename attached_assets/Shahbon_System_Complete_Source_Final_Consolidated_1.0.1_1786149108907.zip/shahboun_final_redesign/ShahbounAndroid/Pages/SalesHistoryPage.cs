using ShahbounAndroid.Models;
using ShahbounAndroid.UI;

namespace ShahbounAndroid.Pages;

public sealed class SalesHistoryPage : ContentPage
{
    public SalesHistoryPage() { Title = "الفواتير"; BackgroundColor = Ui.Surface; }
    protected override async void OnAppearing()
    {
        base.OnAppearing();
        var sales = await AppServices.Database.Db.Table<Sale>().OrderByDescending(x => x.Id).Take(500).ToListAsync();
        var list = new CollectionView
        {
            Margin = 12, ItemsSource = sales, SelectionMode = SelectionMode.Single,
            ItemTemplate = new DataTemplate(() =>
            {
                var l = new Label { TextColor = Ui.Navy, FontSize = 16 };
                l.SetBinding(Label.TextProperty, new Binding(".", converter: new SaleConverter()));
                return Ui.Card(l);
            })
        };
        list.SelectionChanged += async (_, e) =>
        {
            if (e.CurrentSelection.FirstOrDefault() is Sale sale)
            {
                list.SelectedItem = null;
                await Navigation.PushAsync(new InvoiceViewerPage(sale.Id));
            }
        };
        Content = list;
    }
    sealed class SaleConverter : IValueConverter
    {
        public object Convert(object? value, Type targetType, object? parameter, System.Globalization.CultureInfo culture) => value is Sale s ? $"{s.InvoiceNumber}\n{s.CreatedAt:yyyy-MM-dd HH:mm} — {s.Total:0.000} د.ل — {s.PaymentMethod}\nاضغط لفتح الفاتورة" : "";
        public object ConvertBack(object? value, Type targetType, object? parameter, System.Globalization.CultureInfo culture) => throw new NotSupportedException();
    }
}
