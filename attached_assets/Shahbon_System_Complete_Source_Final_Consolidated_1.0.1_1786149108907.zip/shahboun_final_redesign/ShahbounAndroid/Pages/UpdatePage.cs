using ShahbounAndroid.UI;

namespace ShahbounAndroid.Pages;

public sealed class UpdatePage : ContentPage
{
    readonly Entry _url = Ui.Entry("رابط ملف JSON الخاص بالتحديثات");
    readonly Label _status = new() { TextColor = Ui.Muted };
    public UpdatePage()
    {
        Title = "تحديثات المنظومة";
        var save = Ui.Success("حفظ الرابط"); save.Clicked += async (_, _) => { await AppServices.Settings.SetAsync("UpdateManifestUrl", _url.Text ?? ""); _status.Text = "تم حفظ الرابط."; };
        var check = Ui.Primary("التحقق الآن"); check.Clicked += async (_, _) => await CheckAsync();
        Content = new ScrollView { Content = new VerticalStackLayout { Padding = 18, Spacing = 12, Children = { Ui.Title("التحديث من Google Drive"), PromptUtil.Small("ارفع APK وملف JSON على Drive برابط مباشر. التطبيق يتحقق من رقم الإصدار ثم يفتح رابط التنزيل بموافقة المستخدم."), _url, save, check, _status } } };
    }
    protected override async void OnAppearing() { base.OnAppearing(); _url.Text = await AppServices.Settings.GetAsync("UpdateManifestUrl", ""); }
    async Task CheckAsync()
    {
        try
        {
            _status.Text = "جارٍ التحقق...";
            var info = await AppServices.Updates.CheckAsync();
            if (info is null) { _status.Text = "لم يتم إدخال رابط التحديث."; return; }
            if (info.VersionCode <= 8) { _status.Text = $"أنت تستخدم أحدث إصدار ({info.VersionName})."; return; }
            var ok = await DisplayAlert("تحديث متوفر", $"الإصدار {info.VersionName}\n{info.NotesAr}\n{(info.Required ? "هذا تحديث مهم." : "يمكن تثبيته لاحقًا.")}", "تنزيل", "لاحقًا");
            if (ok && Uri.TryCreate(info.DownloadUrl, UriKind.Absolute, out var uri)) await Launcher.Default.OpenAsync(uri);
        }
        catch (Exception ex) { _status.Text = "تعذر التحقق: " + ex.Message; }
    }
}
