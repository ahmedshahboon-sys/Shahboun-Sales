namespace ShahbounAndroid;

public partial class App : Application
{
    public App(){InitializeComponent();}
    protected override Window CreateWindow(IActivationState? activationState)
    {
        var window=new Window(new NavigationPage(new Pages.StartupPage()));
        Dispatcher.Dispatch(async()=>{try{await AppServices.InitializeAsync();await AppServices.Theme.ApplyAsync();}catch{}});
        return window;
    }
}
