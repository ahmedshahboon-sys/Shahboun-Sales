using SQLite;

namespace ShahbounAndroid.Models;

public class AppSetting { [PrimaryKey] public string Key { get; set; } = ""; public string Value { get; set; } = ""; }
public class UserAccount
{
    [PrimaryKey, AutoIncrement] public int Id { get; set; }
    [Unique, NotNull] public string Username { get; set; } = "";
    public string PasswordHash { get; set; } = "";
    public string PasswordSalt { get; set; } = "";
    public bool IsAdmin { get; set; }
    public bool MustChangePassword { get; set; }
    public bool IsActive { get; set; } = true;
    public string PermissionsCsv { get; set; } = "";
}
public class Category { [PrimaryKey, AutoIncrement] public int Id { get; set; } [Unique] public string Name { get; set; } = ""; }
public class Product
{
    [PrimaryKey, AutoIncrement] public int Id { get; set; }
    [Indexed] public string Barcode { get; set; } = "";
    [Indexed] public string Name { get; set; } = "";
    public int CategoryId { get; set; }
    public string Unit { get; set; } = "قطعة";
    public decimal PurchasePriceLyd { get; set; }
    public decimal PurchasePriceUsd { get; set; }
    public decimal SalePrice { get; set; }
    public decimal WholesalePrice { get; set; }
    public decimal Quantity { get; set; }
    public decimal MinimumStock { get; set; }
    public DateTime? ExpiryDate { get; set; }
    public string BatchNumber { get; set; } = "";
    public string PartNumber { get; set; } = "";
    public string VehicleCompatibility { get; set; } = "";
    public string Notes { get; set; } = "";
    public bool IsActive { get; set; } = true;
}
public class Customer { [PrimaryKey, AutoIncrement] public int Id { get; set; } public string Name { get; set; } = ""; public string Phone { get; set; } = ""; public string Address { get; set; } = ""; public decimal Balance { get; set; } }
public class Supplier { [PrimaryKey, AutoIncrement] public int Id { get; set; } public string Name { get; set; } = ""; public string Phone { get; set; } = ""; public string Address { get; set; } = ""; public decimal Balance { get; set; } }
public class Sale
{
    [PrimaryKey, AutoIncrement] public int Id { get; set; }
    [Indexed] public string InvoiceNumber { get; set; } = "";
    public DateTime CreatedAt { get; set; }
    public int UserId { get; set; }
    public int? CustomerId { get; set; }
    public decimal Subtotal { get; set; }
    public decimal Discount { get; set; }
    public decimal Total { get; set; }
    public decimal Paid { get; set; }
    public string PaymentMethod { get; set; } = "نقدي";
    public string Status { get; set; } = "مكتملة";
}
public class SaleItem { [PrimaryKey, AutoIncrement] public int Id { get; set; } [Indexed] public int SaleId { get; set; } public int ProductId { get; set; } public string ProductName { get; set; } = ""; public decimal Quantity { get; set; } public decimal UnitPrice { get; set; } public decimal CostPrice { get; set; } public decimal Total { get; set; } }
public class Purchase
{
    [PrimaryKey, AutoIncrement] public int Id { get; set; }
    public string InvoiceNumber { get; set; } = "";
    public DateTime CreatedAt { get; set; }
    public int? SupplierId { get; set; }
    public decimal Total { get; set; }
    public decimal Paid { get; set; }
    public string Notes { get; set; } = "";
}
public class PurchaseItem { [PrimaryKey, AutoIncrement] public int Id { get; set; } [Indexed] public int PurchaseId { get; set; } public int ProductId { get; set; } public string ProductName { get; set; } = ""; public decimal Quantity { get; set; } public decimal UnitCost { get; set; } public decimal Total { get; set; } }
public class StockMovement { [PrimaryKey, AutoIncrement] public int Id { get; set; } public DateTime CreatedAt { get; set; } public int ProductId { get; set; } public string ProductName { get; set; } = ""; public decimal QuantityChange { get; set; } public string MovementType { get; set; } = ""; public string Reference { get; set; } = ""; public string Notes { get; set; } = ""; }
public class Expense { [PrimaryKey, AutoIncrement] public int Id { get; set; } public DateTime CreatedAt { get; set; } public string Category { get; set; } = ""; public string Description { get; set; } = ""; public decimal Amount { get; set; } }
public class CashTransaction { [PrimaryKey, AutoIncrement] public int Id { get; set; } public DateTime CreatedAt { get; set; } public string Type { get; set; } = "إيداع"; public decimal Amount { get; set; } public string Method { get; set; } = "نقدي"; public string Description { get; set; } = ""; public int UserId { get; set; } }
public class CustomerPayment { [PrimaryKey, AutoIncrement] public int Id { get; set; } public DateTime CreatedAt { get; set; } public int CustomerId { get; set; } public decimal Amount { get; set; } public string Notes { get; set; } = ""; }
public class SupplierPayment { [PrimaryKey, AutoIncrement] public int Id { get; set; } public DateTime CreatedAt { get; set; } public int SupplierId { get; set; } public decimal Amount { get; set; } public string Notes { get; set; } = ""; }
public class ReturnRecord { [PrimaryKey, AutoIncrement] public int Id { get; set; } public DateTime CreatedAt { get; set; } public string ReturnType { get; set; } = "بيع"; public string ReferenceNumber { get; set; } = ""; public decimal Amount { get; set; } public string Reason { get; set; } = ""; }
public class EcommerceOrder { [PrimaryKey, AutoIncrement] public int Id { get; set; } public DateTime CreatedAt { get; set; } public string CustomerName { get; set; } = ""; public string Phone { get; set; } = ""; public string City { get; set; } = ""; public string Source { get; set; } = "فيسبوك"; public string Status { get; set; } = "جديد"; public decimal ProductsTotal { get; set; } public decimal DeliveryFee { get; set; } public string Notes { get; set; } = ""; }
public class AuditLog { [PrimaryKey, AutoIncrement] public int Id { get; set; } public DateTime CreatedAt { get; set; } public string Username { get; set; } = ""; public string Action { get; set; } = ""; public string Details { get; set; } = ""; }
public class ActivationRecord { [PrimaryKey] public int Id { get; set; } = 1; public string DeviceCode { get; set; } = ""; public string LicenseCode { get; set; } = ""; public DateTime ActivatedAt { get; set; } }
public class TrialRecord
{
    [PrimaryKey] public int Id { get; set; } = 1;
    public DateTime StartedAtUtc { get; set; }
    public DateTime ExpiresAtUtc { get; set; }
    public bool IsStarted { get; set; }
    public bool IsLocked { get; set; }
}
public class BusinessProfile
{
    [PrimaryKey] public int Id { get; set; } = 1;
    public string StoreName { get; set; } = "";
    public string OwnerName { get; set; } = "";
    public string Phone { get; set; } = "";
    public string WhatsApp { get; set; } = "";
    public string City { get; set; } = "";
    public string ActivityType { get; set; } = "عام";
    public string Email { get; set; } = "";
    public string LogoPath { get; set; } = "";
    public bool SupportContactConsent { get; set; }
    public DateTime CreatedAtUtc { get; set; }
}
public class ExchangeRateHistory
{
    [PrimaryKey, AutoIncrement] public int Id { get; set; }
    public DateTime ChangedAtUtc { get; set; }
    public decimal OldRate { get; set; }
    public decimal NewRate { get; set; }
    public string ChangedBy { get; set; } = "";
    public bool PricesRecalculated { get; set; }
    public string Notes { get; set; } = "";
}
public class PaymentAccount
{
    [PrimaryKey, AutoIncrement] public int Id { get; set; }
    public string BankName { get; set; } = "";
    public string AccountHolder { get; set; } = "";
    public string AccountNumber { get; set; } = "";
    public string BranchName { get; set; } = "";
    public bool IsDefault { get; set; }
    public bool IsActive { get; set; } = true;
}
public class TransferPayment
{
    [PrimaryKey, AutoIncrement] public int Id { get; set; }
    public DateTime CreatedAtUtc { get; set; }
    public int? SaleId { get; set; }
    public int PaymentAccountId { get; set; }
    public decimal Amount { get; set; }
    public string ReferenceNumber { get; set; } = "";
    public string ProofImagePath { get; set; } = "";
    public string Status { get; set; } = "قيد المراجعة";
    public string ApprovedBy { get; set; } = "";
}

public class Branch
{
    [PrimaryKey, AutoIncrement] public int Id { get; set; }
    [Unique, NotNull] public string Name { get; set; } = "";
    public string Address { get; set; } = "";
    public string Phone { get; set; } = "";
    public bool IsMain { get; set; }
    public bool IsActive { get; set; } = true;
}
public class Warehouse
{
    [PrimaryKey, AutoIncrement] public int Id { get; set; }
    [Indexed] public int BranchId { get; set; }
    [NotNull] public string Name { get; set; } = "";
    public string Location { get; set; } = "";
    public bool IsActive { get; set; } = true;
}
public class WarehouseStock
{
    [PrimaryKey, AutoIncrement] public int Id { get; set; }
    [Indexed] public int WarehouseId { get; set; }
    [Indexed] public int ProductId { get; set; }
    public decimal Quantity { get; set; }
}
public class StockTransfer
{
    [PrimaryKey, AutoIncrement] public int Id { get; set; }
    public DateTime CreatedAtUtc { get; set; }
    public int FromWarehouseId { get; set; }
    public int ToWarehouseId { get; set; }
    public string Reference { get; set; } = "";
    public string Status { get; set; } = "مكتمل";
    public string CreatedBy { get; set; } = "";
}
public class StockTransferItem
{
    [PrimaryKey, AutoIncrement] public int Id { get; set; }
    [Indexed] public int TransferId { get; set; }
    public int ProductId { get; set; }
    public decimal Quantity { get; set; }
}
public class WorkShift
{
    [PrimaryKey, AutoIncrement] public int Id { get; set; }
    public int UserId { get; set; }
    public int BranchId { get; set; }
    public DateTime OpenedAtUtc { get; set; }
    public DateTime? ClosedAtUtc { get; set; }
    public decimal OpeningCash { get; set; }
    public decimal ClosingCash { get; set; }
    public string Status { get; set; } = "مفتوحة";
    public string Notes { get; set; } = "";
}
public class Role
{
    [PrimaryKey, AutoIncrement] public int Id { get; set; }
    [Unique, NotNull] public string Name { get; set; } = "";
    public string PermissionsCsv { get; set; } = "";
    public bool IsSystem { get; set; }
}
public class UserRole
{
    [PrimaryKey, AutoIncrement] public int Id { get; set; }
    [Indexed] public int UserId { get; set; }
    [Indexed] public int RoleId { get; set; }
}
public class DatabaseMigration
{
    [PrimaryKey] public int Version { get; set; }
    public DateTime AppliedAtUtc { get; set; }
    public string Description { get; set; } = "";
}
