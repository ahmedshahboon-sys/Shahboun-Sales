// Shahboun Licensing 6.0.0 - Expo config
// EAS projectId is intentionally pinned to the existing private project so Android signing stays compatible with 2.5.0 upgrades.
module.exports = {
  expo: {
    owner: 'ahmedshahboon',
    name: '\u0634\u0647\u0628\u0648\u0646 \u0644\u0644\u062a\u0631\u0627\u062e\u064a\u0635 \u0648\u0627\u0644\u062a\u0641\u0639\u064a\u0644',
    slug: 'shahboun-licensing-final',
    version: '6.0.1',
    orientation: 'default',
    icon: './assets/icon.jpg',
    userInterfaceStyle: 'automatic',
    backgroundColor: '#FFFFFF',
    primaryColor: '#1A2B4C',
    splash: {
      image: './assets/splash.jpg',
      resizeMode: 'contain',
      backgroundColor: '#FFFFFF'
    },
    android: {
      package: 'com.shahboun.licensing',
      versionCode: 61,
      adaptiveIcon: {
        foregroundImage: './assets/adaptive-icon.jpg',
        backgroundColor: '#FFFFFF'
      }
    },
    plugins: [
      'expo-secure-store',
      'expo-sqlite',
      'expo-document-picker',
      'expo-system-ui',
      './plugins/withLicensingSecurity'
    ],
    assetBundlePatterns: ['**/*'],
    scheme: 'shahboun-licensing',
    jsEngine: 'hermes',
    newArchEnabled: false,
    extra: { eas: { projectId: '9d835e52-7b7d-4a80-83a6-b21ad88b0666' } }
  }
};
