@echo off
title Shahboun LAN/Web Server
cd /d "%~dp0"
call npm.cmd start
pause
