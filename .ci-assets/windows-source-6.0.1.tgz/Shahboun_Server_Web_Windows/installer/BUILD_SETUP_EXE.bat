@echo off
set ISCC="%ProgramFiles(x86)%\Inno Setup 6\ISCC.exe"
if not exist %ISCC% set ISCC="%ProgramFiles%\Inno Setup 6\ISCC.exe"
if not exist %ISCC% (
 echo Inno Setup 6 is not installed.
 echo Install Inno Setup 6 then run this file again.
 pause
 exit /b 1
)
%ISCC% ShahbounServerSetup.iss
pause
